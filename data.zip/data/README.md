# data/ folder

Place the six original company CSV files here with exactly these names:

- `TVS Motors.csv`
- `TCS.csv`
- `Infosys.csv`
- `Hero Motocorp.csv`
- `Eicher Motors.csv`
- `Bajaj Auto.csv`

The app combines them with `pandas.concat()` and adds a `Company` column.

If none of them are present, the app falls back to `cleaned_data.csv` (the already-combined,
cleaned dataset shipped in this folder). Optional: `powerpoint_findings.json` holds
source-reported PowerPoint observations as `{"Company": "text"}`.
