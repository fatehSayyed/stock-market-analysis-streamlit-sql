"""Central configuration: paths, canonical column names, colour palette."""
from pathlib import Path

# ---------------------------------------------------------------- paths
# Everything is relative to the project folder, never a machine-specific path.
BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "data"
OUTPUT_DIR = BASE_DIR / "outputs"
PPT_FINDINGS_FILE = DATA_DIR / "powerpoint_findings.json"
SQL_SCRIPT_FILE = BASE_DIR / "stock_analysis.sql"

# The six original CSV files (company name -> file name inside data/).
COMPANY_FILES = {
    "TVS Motors": "TVS Motors.csv",
    "TCS": "TCS.csv",
    "Infosys": "Infosys.csv",
    "Hero Motocorp": "Hero Motocorp.csv",
    "Eicher Motors": "Eicher Motors.csv",
    "Bajaj Auto": "Bajaj Auto.csv",
}
# Used only when none of the six original files are present in data/.
FALLBACK_FILE = "cleaned_data.csv"

# ---------------------------------------------------------------- columns
DATE = "Date"
OPEN = "Open Price"
HIGH = "High Price"
LOW = "Low Price"
CLOSE = "Close Price"
WAP = "WAP"
SHARES = "No.of Shares"
TRADES = "No. of Trades"
TURNOVER = "Total Turnover (Rs.)"
DELIV = "Deliverable Quantity"
DELIV_PCT = "% Deli. Qty to Traded Qty"
SPREAD_HL = "Spread High-Low"
SPREAD_CO = "Spread Close-Open"
COMPANY = "Company"
RET = "Daily Return (%)"
MA30 = "MA30"
MA90 = "MA90"

NUMERIC_COLS = [OPEN, HIGH, LOW, CLOSE, WAP, SHARES, TRADES, TURNOVER,
                DELIV, DELIV_PCT, SPREAD_HL, SPREAD_CO]
PRICE_COLS = [OPEN, HIGH, LOW, CLOSE, WAP]
REQUIRED_COLS = [DATE, CLOSE]                      # app cannot work without these
ALL_COLS = [DATE, OPEN, HIGH, LOW, CLOSE, WAP, SHARES, TRADES, TURNOVER,
            DELIV, DELIV_PCT, SPREAD_HL, SPREAD_CO, COMPANY, RET]

TRADING_DAYS_PER_YEAR = 252

# ---------------------------------------------------------------- theme
BG = "#101020"
PANEL = "#19192D"
RED = "#D64550"
PINK = "#A64D79"
TEXT = "#FFFFFF"
MUTED = "#B8B8C8"
BORDER = "#2A2A40"
GRID = "#262640"
POS = "#4FB3BF"      # positive returns (kept cool so red always means "down")
NEG = RED

# Restrained 6-colour palette for company series (red/pink family + neutrals).
COMPANY_COLORS = {
    "Bajaj Auto": "#D64550",
    "Eicher Motors": "#E9A23B",
    "Hero Motocorp": "#A64D79",
    "Infosys": "#4FB3BF",
    "TCS": "#EDEDF5",
    "TVS Motors": "#8E8CD8",
}
FALLBACK_COLORS = ["#D64550", "#A64D79", "#EDEDF5", "#E9A23B", "#4FB3BF", "#8E8CD8",
                   "#7BC47F", "#C98B6B"]


def color_for(company: str, idx: int = 0) -> str:
    """Stable colour per company; falls back to a palette for uploaded names."""
    return COMPANY_COLORS.get(company, FALLBACK_COLORS[idx % len(FALLBACK_COLORS)])
