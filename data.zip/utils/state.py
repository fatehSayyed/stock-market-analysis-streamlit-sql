"""Session state: the active dataset lives in st.session_state['df']."""
from __future__ import annotations

import pandas as pd
import streamlit as st

from . import analytics as an
from . import config as C
from . import data_loader as dl


@st.cache_data(show_spinner="Loading datasets...")
def _load_default_cached():
    raw, info = dl.load_default()
    res = dl.clean_data(raw)
    return raw, res.df, res.log, info


def init_state(force: bool = False):
    """Load the bundled dataset into session state (once per session)."""
    if force:
        _load_default_cached.clear()
        for k in ("df", "raw_df", "clean_log", "source_info", "load_error"):
            st.session_state.pop(k, None)
    if "df" in st.session_state:
        return
    try:
        raw, df, log, info = _load_default_cached()
        set_dataset(raw, df, log, info)
    except Exception as exc:                       # missing files, bad CSV ...
        st.session_state.update(df=pd.DataFrame(columns=C.ALL_COLS), raw_df=pd.DataFrame(),
                                clean_log=[], source_info={"mode": "none", "found": [], "missing": []},
                                load_error=str(exc))


def set_dataset(raw: pd.DataFrame, clean_df: pd.DataFrame, log: list, info: dict):
    """Install a (cleaned) dataset and reset every page filter that depends on it."""
    for k in [k for k in st.session_state if str(k).startswith(("f_", "sql_"))]:
        del st.session_state[k]
    st.session_state.update(raw_df=raw, df=an.add_indicators(clean_df), clean_log=log,
                            source_info=info, sql_result=None)
    st.session_state.pop("load_error", None)
    st.session_state.pop("pdf_bytes", None)


def get_df() -> pd.DataFrame:
    return st.session_state["df"]


def has_data() -> bool:
    return len(st.session_state.get("df", [])) > 0
