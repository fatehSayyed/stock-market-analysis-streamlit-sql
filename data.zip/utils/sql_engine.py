"""Safe, local SQL execution on the combined dataset using DuckDB.

Safety layers
-------------
1. Static validation: a single SELECT/WITH/DESCRIBE statement; destructive and
   file/system keywords are rejected (string literals and comments are ignored).
2. The database is in-memory and only contains the registered `stock_data` table.
3. DuckDB external access is disabled and configuration is locked.
4. A row cap, a memory cap and a wall-clock timeout (query interrupt) are applied.
"""
from __future__ import annotations

import re
import threading
import time
from dataclasses import dataclass

import duckdb
import pandas as pd

from . import config as C

MAX_ROWS = 10_000
TIMEOUT_SECONDS = 20

# pandas column -> SQL column (snake_case, no spaces -> no quoting needed)
SQL_COLUMNS = {
    C.DATE: "trade_date", C.COMPANY: "company",
    C.OPEN: "open_price", C.HIGH: "high_price", C.LOW: "low_price", C.CLOSE: "close_price",
    C.WAP: "wap", C.SHARES: "no_of_shares", C.TRADES: "no_of_trades",
    C.TURNOVER: "total_turnover", C.DELIV: "deliverable_quantity",
    C.DELIV_PCT: "pct_deliverable", C.SPREAD_HL: "spread_high_low",
    C.SPREAD_CO: "spread_close_open", C.RET: "daily_return_pct",
}
COLUMN_DOCS = {
    "trade_date": "Trading date (DATE)", "company": "Company name",
    "open_price": "Opening price (Rs.)", "high_price": "Day high (Rs.)",
    "low_price": "Day low (Rs.)", "close_price": "Closing price (Rs.)",
    "wap": "Weighted average price (Rs.)", "no_of_shares": "Shares traded (volume)",
    "no_of_trades": "Number of trades", "total_turnover": "Traded value (Rs.)",
    "deliverable_quantity": "Shares marked for delivery (may be NULL)",
    "pct_deliverable": "Deliverable qty as % of traded qty (may be NULL)",
    "spread_high_low": "High - Low", "spread_close_open": "Close - Open",
    "daily_return_pct": "% change of close vs. previous trading day (NULL on first day)",
}

_FORBIDDEN = [
    "DROP", "DELETE", "UPDATE", "INSERT", "ALTER", "CREATE", "TRUNCATE", "ATTACH", "DETACH",
    "COPY", "EXPORT", "IMPORT", "INSTALL", "LOAD", "PRAGMA", "SET", "RESET", "CALL", "MERGE",
    "GRANT", "REVOKE", "VACUUM", "CHECKPOINT", "USE", "BEGIN", "COMMIT", "ROLLBACK",
    "READ_CSV", "READ_CSV_AUTO", "READ_PARQUET", "READ_JSON", "READ_TEXT", "READ_BLOB",
    "GLOB", "PARQUET_SCAN", "SNIFF_CSV", "DUCKDB_SETTINGS",
]
_FORBIDDEN_RE = re.compile(r"\b(" + "|".join(_FORBIDDEN) + r")\b", re.IGNORECASE)
_ALLOWED_START = ("SELECT", "WITH", "DESCRIBE", "FROM")


@dataclass
class QueryResult:
    df: pd.DataFrame | None = None
    error: str | None = None
    elapsed_ms: float = 0.0
    truncated: bool = False
    sql: str = ""


def to_sql_frame(df: pd.DataFrame) -> pd.DataFrame:
    """Subset/rename columns to the SQL schema; Date becomes a true DATE."""
    cols = {k: v for k, v in SQL_COLUMNS.items() if k in df.columns}
    out = df[list(cols)].rename(columns=cols).copy()
    out["trade_date"] = out["trade_date"].dt.date
    return out


def _strip_comments_and_literals(sql: str) -> str:
    sql = re.sub(r"/\*.*?\*/", " ", sql, flags=re.S)
    sql = re.sub(r"--[^\n]*", " ", sql)
    return re.sub(r"'(?:[^']|'')*'", "''", sql)          # blank out string literals


def validate_query(sql: str) -> tuple[bool, str, str]:
    """Return (ok, message, normalised_sql)."""
    if not sql or not sql.strip():
        return False, "The query is empty.", ""
    body = _strip_comments_and_literals(sql).strip().rstrip(";").strip()
    if not body:
        return False, "The query contains only comments.", ""
    if ";" in body:
        return False, "Only one statement can be executed at a time (remove extra ';').", ""
    first = body.split(None, 1)[0].upper()
    if first not in _ALLOWED_START:
        return False, (f"Only read-only SELECT / WITH / DESCRIBE statements are allowed "
                       f"(found '{first}')."), ""
    hit = _FORBIDDEN_RE.search(body)
    if hit:
        return False, f"Blocked keyword '{hit.group(1).upper()}': this playground is read-only.", ""
    cleaned = re.sub(r"--[^\n]*", " ", re.sub(r"/\*.*?\*/", " ", sql, flags=re.S)).strip().rstrip(";").strip()
    return True, "ok", cleaned


def _connect(df: pd.DataFrame) -> duckdb.DuckDBPyConnection:
    con = duckdb.connect(":memory:")
    con.register("stock_data_src", to_sql_frame(df))
    con.execute("CREATE TABLE stock_data AS SELECT * FROM stock_data_src")
    con.unregister("stock_data_src")
    con.execute("SET memory_limit='1GB'")
    con.execute("SET threads=2")
    con.execute("SET enable_external_access=false")
    con.execute("SET lock_configuration=true")
    return con


def get_schema(df: pd.DataFrame) -> pd.DataFrame:
    """Column names and DuckDB data types of `stock_data`."""
    con = _connect(df)
    try:
        sch = con.execute("DESCRIBE stock_data").df()[["column_name", "column_type"]]
    finally:
        con.close()
    sch.columns = ["Column", "Type"]
    sch["Description"] = sch["Column"].map(COLUMN_DOCS).fillna("")
    return sch


def run_query(df: pd.DataFrame, sql: str, max_rows: int = MAX_ROWS,
              timeout: float = TIMEOUT_SECONDS) -> QueryResult:
    """Validate and execute `sql` against `df` registered as table `stock_data`."""
    ok, msg, cleaned = validate_query(sql)
    if not ok:
        return QueryResult(error=msg, sql=sql)
    con = None
    timer = None
    t0 = time.perf_counter()
    try:
        con = _connect(df)
        timer = threading.Timer(timeout, con.interrupt)   # wall-clock timeout
        timer.start()
        cur = con.execute(cleaned)
        cols = [d[0] for d in cur.description]
        rows = cur.fetchmany(max_rows + 1)
        truncated = len(rows) > max_rows
        out = pd.DataFrame(rows[:max_rows], columns=cols)
        return QueryResult(df=out, truncated=truncated, sql=cleaned,
                           elapsed_ms=(time.perf_counter() - t0) * 1000)
    except duckdb.InterruptException:
        return QueryResult(error=f"Query stopped: it ran longer than {timeout:.0f} seconds.", sql=cleaned)
    except Exception as exc:                               # surface DuckDB's own message
        return QueryResult(error=f"{type(exc).__name__}: {exc}", sql=cleaned,
                           elapsed_ms=(time.perf_counter() - t0) * 1000)
    finally:
        if timer:
            timer.cancel()
        if con is not None:
            con.close()
