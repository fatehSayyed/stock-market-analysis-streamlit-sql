"""Reusable modules for the Stock Market Analysis Dashboard."""
