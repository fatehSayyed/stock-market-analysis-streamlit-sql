"""Plotly chart builders in the navy / red / white terminal style."""
from __future__ import annotations

import numpy as np
import pandas as pd
import plotly.graph_objects as go

from . import config as C


def style(fig: go.Figure, height: int = 340, legend: bool = True, hover="x unified") -> go.Figure:
    fig.update_layout(
        template="plotly_dark", paper_bgcolor=C.PANEL, plot_bgcolor=C.PANEL, height=height,
        font=dict(color=C.MUTED, family="Inter, Segoe UI, system-ui, sans-serif", size=12),
        margin=dict(l=8, r=8, t=28, b=8), hovermode=hover, showlegend=legend,
        legend=dict(orientation="h", y=1.12, x=0, bgcolor="rgba(0,0,0,0)", font=dict(size=11)),
        hoverlabel=dict(bgcolor=C.BG, bordercolor=C.BORDER, font=dict(color=C.TEXT)),
    )
    fig.update_xaxes(gridcolor=C.GRID, zeroline=False, linecolor=C.BORDER, tickfont=dict(size=11))
    fig.update_yaxes(gridcolor=C.GRID, zeroline=False, linecolor=C.BORDER, tickfont=dict(size=11))
    return fig


def _colors(companies) -> dict:
    return {c: C.color_for(c, i) for i, c in enumerate(companies)}


# ------------------------------------------------------------------ price charts
def price_chart(df: pd.DataFrame, ma30=True, ma90=True, height=360) -> go.Figure:
    """Close line (filled) with optional 30/90-day moving averages — single company."""
    fig = go.Figure()
    fig.add_trace(go.Scatter(x=df[C.DATE], y=df[C.CLOSE], name="Close", mode="lines",
                             line=dict(color=C.RED, width=2), fill="tozeroy",
                             fillcolor="rgba(214,69,80,0.10)"))
    if ma30:
        fig.add_trace(go.Scatter(x=df[C.DATE], y=df[C.MA30], name="30-day MA", mode="lines",
                                 line=dict(color="#EDEDF5", width=1.4)))
    if ma90:
        fig.add_trace(go.Scatter(x=df[C.DATE], y=df[C.MA90], name="90-day MA", mode="lines",
                                 line=dict(color=C.PINK, width=1.4, dash="dot")))
    lo, hi = df[C.CLOSE].min(), df[C.CLOSE].max()
    pad = (hi - lo) * 0.08 or 1
    fig.update_yaxes(range=[lo - pad, hi + pad], title_text="Price (Rs.)")
    return style(fig, height)


def candlestick(df: pd.DataFrame, height=380) -> go.Figure:
    fig = go.Figure(go.Candlestick(
        x=df[C.DATE], open=df[C.OPEN], high=df[C.HIGH], low=df[C.LOW], close=df[C.CLOSE], name="OHLC",
        increasing=dict(line=dict(color=C.POS), fillcolor=C.POS),
        decreasing=dict(line=dict(color=C.NEG), fillcolor=C.NEG)))
    fig.add_trace(go.Scatter(x=df[C.DATE], y=df[C.WAP], name="WAP", mode="lines",
                             line=dict(color="#EDEDF5", width=1.2)))
    fig.update_layout(xaxis_rangeslider_visible=False)
    return style(fig, height)


def multi_line(df: pd.DataFrame, y: str, ylabel: str | None = None, height=340, hline=None) -> go.Figure:
    comps = list(df[C.COMPANY].unique())
    cols = _colors(comps)
    fig = go.Figure()
    for comp in comps:
        g = df[df[C.COMPANY] == comp]
        fig.add_trace(go.Scatter(x=g[C.DATE], y=g[y], name=comp, mode="lines",
                                 line=dict(color=cols[comp], width=1.7)))
    if hline is not None:
        fig.add_hline(y=hline, line=dict(color=C.MUTED, width=1, dash="dot"))
    fig.update_yaxes(title_text=ylabel or y)
    return style(fig, height)


def multi_bar_ts(df: pd.DataFrame, y: str, ylabel: str | None = None, height=300) -> go.Figure:
    """Time-series bars per company (grouped by overlay)."""
    comps = list(df[C.COMPANY].unique())
    cols = _colors(comps)
    fig = go.Figure()
    for comp in comps:
        g = df[df[C.COMPANY] == comp]
        fig.add_trace(go.Bar(x=g[C.DATE], y=g[y], name=comp, marker_color=cols[comp]))
    fig.update_layout(barmode="overlay" if len(comps) > 1 else "relative")
    if len(comps) > 1:
        fig.update_traces(opacity=0.75)
    fig.update_yaxes(title_text=ylabel or y)
    return style(fig, height)


def volume_chart(df: pd.DataFrame, height=230) -> go.Figure:
    fig = go.Figure(go.Bar(x=df[C.DATE], y=df[C.SHARES], name="Shares traded",
                           marker_color=C.PINK))
    fig.update_yaxes(title_text="Shares")
    return style(fig, height, legend=False)


def turnover_chart(df: pd.DataFrame, height=260) -> go.Figure:
    fig = go.Figure(go.Bar(x=df[C.DATE], y=df[C.TURNOVER] / 1e7, name="Turnover (Rs. Cr)",
                           marker_color=C.RED))
    fig.update_yaxes(title_text="Rs. crore")
    return style(fig, height, legend=False)


def returns_chart(df: pd.DataFrame, height=260) -> go.Figure:
    r = df[C.RET]
    fig = go.Figure(go.Bar(x=df[C.DATE], y=r, name="Daily return (%)",
                           marker_color=np.where(r >= 0, C.POS, C.NEG)))
    fig.update_yaxes(title_text="%")
    return style(fig, height, legend=False)


def histogram(df: pd.DataFrame, col: str, by_company=True, bins=60, height=320,
              xlabel: str | None = None, log_y=False) -> go.Figure:
    fig = go.Figure()
    if by_company:
        comps = list(df[C.COMPANY].unique())
        cols = _colors(comps)
        for comp in comps:
            fig.add_trace(go.Histogram(x=df.loc[df[C.COMPANY] == comp, col], name=comp, nbinsx=bins,
                                       marker_color=cols[comp], opacity=0.65))
        fig.update_layout(barmode="overlay")
    else:
        fig.add_trace(go.Histogram(x=df[col], nbinsx=bins, marker_color=C.RED))
    fig.update_xaxes(title_text=xlabel or col)
    fig.update_yaxes(title_text="Frequency", type="log" if log_y else "linear")
    return style(fig, height, legend=by_company, hover="closest")


def box_chart(df: pd.DataFrame, col: str, height=320) -> go.Figure:
    comps = list(df[C.COMPANY].unique())
    cols = _colors(comps)
    fig = go.Figure()
    for comp in comps:
        fig.add_trace(go.Box(y=df.loc[df[C.COMPANY] == comp, col], name=comp, marker_color=cols[comp],
                             line=dict(color=cols[comp]), boxpoints="outliers"))
    return style(fig, height, legend=False, hover="closest")


# ------------------------------------------------------------------ categorical bars
def bar(df: pd.DataFrame, x: str, y: str, height=300, signed=False, fmt=".2f", horizontal=False,
        ylabel: str | None = None) -> go.Figure:
    """Bar chart by company. `signed` colours gains/losses differently."""
    d = df.copy()
    if signed:
        colors = np.where(d[y] >= 0, C.POS, C.NEG)
    else:
        colors = [C.color_for(c, i) for i, c in enumerate(d[x])] if x == C.COMPANY else C.RED
    if horizontal:
        fig = go.Figure(go.Bar(y=d[x], x=d[y], orientation="h", marker_color=colors,
                               text=d[y].map(lambda v: f"{v:{fmt}}"), textposition="outside",
                               cliponaxis=False))
        fig.update_yaxes(autorange="reversed")
        fig.update_xaxes(title_text=ylabel or y)
    else:
        fig = go.Figure(go.Bar(x=d[x], y=d[y], marker_color=colors,
                               text=d[y].map(lambda v: f"{v:{fmt}}"), textposition="outside",
                               cliponaxis=False))
        fig.update_yaxes(title_text=ylabel or y)
    return style(fig, height, legend=False, hover="closest")


def heatmap(corr: pd.DataFrame, height=420, title_zmid=0.0) -> go.Figure:
    fig = go.Figure(go.Heatmap(
        z=corr.values, x=list(corr.columns), y=list(corr.index), zmin=-1, zmax=1, zmid=title_zmid,
        colorscale=[[0, "#4FB3BF"], [0.5, C.PANEL], [1, C.RED]],
        text=np.round(corr.values, 2), texttemplate="%{text}", textfont=dict(size=11, color=C.TEXT),
        colorbar=dict(thickness=10, tickfont=dict(color=C.MUTED))))
    fig.update_yaxes(autorange="reversed")
    return style(fig, height, legend=False, hover="closest")


def missing_heatmap(miss_pct: pd.DataFrame, height=300) -> go.Figure:
    """Company x column heat map of % missing values."""
    fig = go.Figure(go.Heatmap(
        z=miss_pct.values, x=list(miss_pct.columns), y=list(miss_pct.index), zmin=0,
        colorscale=[[0, C.PANEL], [1, C.RED]],
        text=np.round(miss_pct.values, 2), texttemplate="%{text}%", textfont=dict(size=11),
        colorbar=dict(thickness=10, title=dict(text="% missing", font=dict(color=C.MUTED)))))
    fig.update_yaxes(autorange="reversed")
    return style(fig, height, legend=False, hover="closest")


def drawdown_chart(dd: pd.DataFrame, height=320) -> go.Figure:
    comps = list(dd[C.COMPANY].unique())
    cols = _colors(comps)
    fig = go.Figure()
    for comp in comps:
        g = dd[dd[C.COMPANY] == comp]
        fig.add_trace(go.Scatter(x=g[C.DATE], y=g["Drawdown (%)"], name=comp, mode="lines",
                                 line=dict(color=cols[comp], width=1.5)))
    fig.update_yaxes(title_text="Drawdown (%)")
    return style(fig, height)
