"""Data loading, column standardisation and cleaning.

Principles
----------
* Never invent financial data: missing values stay missing (NULL / NaN).
* Every change made to the data is written to a cleaning log that the app shows.
* The raw frame is kept untouched; analysis runs on a cleaned copy.
"""
from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path
from typing import IO

import numpy as np
import pandas as pd

from . import config as C

# Normalised header (lower-case, alphanumerics only) -> canonical column name.
_ALIASES = {
    "date": C.DATE,
    "openprice": C.OPEN, "open": C.OPEN,
    "highprice": C.HIGH, "high": C.HIGH,
    "lowprice": C.LOW, "low": C.LOW,
    "closeprice": C.CLOSE, "close": C.CLOSE,
    "wap": C.WAP,
    "noofshares": C.SHARES, "shares": C.SHARES, "volume": C.SHARES,
    "nooftrades": C.TRADES, "trades": C.TRADES,
    "totalturnoverrs": C.TURNOVER, "totalturnover": C.TURNOVER, "turnover": C.TURNOVER,
    "deliverablequantity": C.DELIV,
    "deliqtytotradedqty": C.DELIV_PCT, "deliverablepercentage": C.DELIV_PCT,
    "spreadhighlow": C.SPREAD_HL, "spreadhl": C.SPREAD_HL,
    "spreadcloseopen": C.SPREAD_CO, "spreadco": C.SPREAD_CO,
    "company": C.COMPANY, "symbol": C.COMPANY,
    "dailyreturn": C.RET, "dailyreturnpct": C.RET,
}


@dataclass
class CleanResult:
    df: pd.DataFrame
    log: list[dict]          # [{"step":..., "detail":..., "rows":...}]


# --------------------------------------------------------------------------- reading
def read_csv_any(source: str | Path | IO) -> pd.DataFrame:
    """Read a CSV trying a few common encodings."""
    last_err: Exception | None = None
    for enc in ("utf-8", "utf-8-sig", "latin-1"):
        try:
            if hasattr(source, "seek"):
                source.seek(0)
            return pd.read_csv(source, encoding=enc)
        except UnicodeDecodeError as err:
            last_err = err
    raise ValueError(f"Could not decode CSV: {last_err}")


def normalize_columns(df: pd.DataFrame) -> tuple[pd.DataFrame, dict]:
    """Rename headers to the canonical names. Returns (frame, {old: new})."""
    mapping: dict[str, str] = {}
    used: set[str] = set()
    for col in df.columns:
        key = re.sub(r"[^a-z0-9]", "", str(col).lower())
        target = _ALIASES.get(key)
        if target and target not in used:
            mapping[col] = target
            used.add(target)
    return df.rename(columns=mapping), mapping


def missing_expected_columns(df: pd.DataFrame, company_known: bool = True) -> dict:
    """Which expected columns are absent after normalisation."""
    cols = set(df.columns)
    expected = [c for c in C.ALL_COLS if c != C.RET]          # return is derived
    if company_known:
        expected = [c for c in expected if c != C.COMPANY]
    missing = [c for c in expected if c not in cols]
    return {"required": [c for c in missing if c in C.REQUIRED_COLS],
            "optional": [c for c in missing if c not in C.REQUIRED_COLS]}


def load_company_file(path: Path, company: str) -> pd.DataFrame:
    """Load one company's CSV, standardise headers and tag the company."""
    df, _ = normalize_columns(read_csv_any(path))
    df = df.drop(columns=[c for c in df.columns if str(c).startswith("Unnamed")])
    df[C.COMPANY] = company
    return df


def load_default(data_dir: Path = C.DATA_DIR) -> tuple[pd.DataFrame, dict]:
    """Load the six original files (preferred) or the fallback cleaned file.

    Returns the *raw combined* frame and an info dict describing what was used.
    """
    found, missing, frames = [], [], []
    for company, fname in C.COMPANY_FILES.items():
        path = data_dir / fname
        if path.exists():
            frames.append(load_company_file(path, company))
            found.append(fname)
        else:
            missing.append(fname)

    if frames:
        raw = pd.concat(frames, ignore_index=True)            # vertical combine
        return raw, {"mode": "original_files", "found": found, "missing": missing}

    fallback = data_dir / C.FALLBACK_FILE
    if fallback.exists():
        df, _ = normalize_columns(read_csv_any(fallback))
        return df, {"mode": "fallback", "found": [C.FALLBACK_FILE], "missing": missing}

    raise FileNotFoundError(
        f"No data found in '{data_dir}'. Place the six company CSVs there "
        f"or use the Dataset Management page to upload them.")


# --------------------------------------------------------------------------- cleaning
def clean_data(raw: pd.DataFrame) -> CleanResult:
    """Return a cleaned copy plus a log of everything that was changed."""
    log: list[dict] = []

    def note(step: str, detail: str, rows: int = 0):
        log.append({"step": step, "detail": detail, "rows": int(rows)})

    df, _ = normalize_columns(raw.copy())
    note("Load", f"Input has {len(df):,} rows and {df.shape[1]} columns.", len(df))

    # 1. irrelevant columns
    unnamed = [c for c in df.columns if str(c).startswith("Unnamed")]
    if unnamed:
        df = df.drop(columns=unnamed)
        note("Drop columns", f"Removed empty/irrelevant column(s): {', '.join(map(str, unnamed))}.")

    missing_req = [c for c in C.REQUIRED_COLS if c not in df.columns]
    if missing_req:
        raise ValueError(f"Required column(s) missing: {', '.join(missing_req)}")

    # 2. company
    if C.COMPANY not in df.columns:
        df[C.COMPANY] = "Unknown"
        note("Company", "No Company column – every row labelled 'Unknown'.")
    df[C.COMPANY] = df[C.COMPANY].astype(str).str.strip()

    # 3. dates
    parsed = pd.to_datetime(df[C.DATE], errors="coerce")
    bad = int(parsed.isna().sum())
    if bad:
        df = df.loc[parsed.notna()].copy()
        parsed = parsed.loc[df.index]
        note("Invalid dates", f"Dropped {bad} row(s) whose Date could not be parsed.", bad)
    df[C.DATE] = parsed.dt.normalize()

    # 4. numeric conversion (never fills values)
    for col in C.NUMERIC_COLS:
        if col not in df.columns:
            continue
        if df[col].dtype == object:
            cleaned = df[col].astype(str).str.replace(",", "", regex=False).str.strip()
            cleaned = cleaned.replace({"": np.nan, "nan": np.nan, "None": np.nan, "-": np.nan})
            conv = pd.to_numeric(cleaned, errors="coerce")
            lost = int((conv.isna() & df[col].notna() & ~cleaned.isna()).sum())
            if lost:
                note("Numeric conversion", f"{lost} non-numeric value(s) in '{col}' became missing.", lost)
            df[col] = conv
        else:
            df[col] = pd.to_numeric(df[col], errors="coerce")

    # 5. exact duplicates
    dups = int(df.duplicated().sum())
    if dups:
        df = df.drop_duplicates()
        note("Duplicates", f"Removed {dups} exact duplicate row(s).", dups)
    else:
        note("Duplicates", "No exact duplicate rows found.")

    # 6. sort and optional columns
    df = df.sort_values([C.COMPANY, C.DATE]).reset_index(drop=True)
    for col in C.NUMERIC_COLS:
        if col not in df.columns:
            df[col] = np.nan
            note("Absent column", f"'{col}' not in the data – stored as NULL (not estimated).")

    # derived spreads only if the source columns exist and the spread is entirely absent
    if df[C.SPREAD_HL].isna().all() and df[C.HIGH].notna().any():
        df[C.SPREAD_HL] = df[C.HIGH] - df[C.LOW]
        note("Derived", "Spread High-Low computed as High - Low.")
    if df[C.SPREAD_CO].isna().all() and df[C.CLOSE].notna().any() and df[C.OPEN].notna().any():
        df[C.SPREAD_CO] = df[C.CLOSE] - df[C.OPEN]
        note("Derived", "Spread Close-Open computed as Close - Open.")

    # 7. daily return, per company, chronological
    original = df[C.RET].copy() if C.RET in df.columns else None
    df[C.RET] = df.groupby(C.COMPANY, sort=False)[C.CLOSE].pct_change(fill_method=None) * 100
    if original is not None:
        both = original.notna() & df[C.RET].notna()
        diff = float((original[both] - df.loc[both, C.RET]).abs().max()) if both.any() else 0.0
        note("Daily return", f"Recomputed per company as % change of Close; max difference "
                             f"vs. supplied column = {diff:.6f} percentage points.")
    else:
        note("Daily return", "Computed per company as % change of Close Price.")

    # 8. missing values are reported, not filled
    n_missing = int(df[C.NUMERIC_COLS].isna().sum().sum())
    note("Missing values", f"{n_missing} missing numeric cell(s) left as missing (no imputation).", n_missing)

    df = df[[c for c in C.ALL_COLS if c in df.columns]]
    note("Done", f"Clean dataset: {len(df):,} rows, {df[C.COMPANY].nunique()} companies, "
                 f"{df[C.DATE].min():%Y-%m-%d} to {df[C.DATE].max():%Y-%m-%d}.", len(df))
    return CleanResult(df=df, log=log)
