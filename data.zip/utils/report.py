"""PDF report generation (ReportLab + Matplotlib).

The PDF keeps *calculated* findings (computed from the data) strictly separate from
*source-reported* findings (the PowerPoint observations supplied by the user).
"""
from __future__ import annotations

import io
from datetime import date
from xml.sax.saxutils import escape

import matplotlib
matplotlib.use("Agg")                       # headless backend
import matplotlib.pyplot as plt             # noqa: E402
import numpy as np                          # noqa: E402
import pandas as pd                         # noqa: E402
from reportlab.lib import colors            # noqa: E402
from reportlab.lib.enums import TA_LEFT     # noqa: E402
from reportlab.lib.pagesizes import A4      # noqa: E402
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet  # noqa: E402
from reportlab.lib.units import cm          # noqa: E402
from reportlab.platypus import (Image, PageBreak, Paragraph, SimpleDocTemplate,  # noqa: E402
                                Spacer, Table, TableStyle, KeepTogether)

from . import analytics as an
from . import config as C

NAVY = colors.HexColor(C.BG)
RED = colors.HexColor(C.RED)
GREY = colors.HexColor("#555566")
LIGHT = colors.HexColor("#F2F2F7")


# --------------------------------------------------------------------------- charts
def _fig_to_image(fig, width_cm=17, height_cm=7) -> Image:
    buf = io.BytesIO()
    fig.savefig(buf, format="png", dpi=170, bbox_inches="tight", facecolor="white")
    plt.close(fig)
    buf.seek(0)
    return Image(buf, width=width_cm * cm, height=height_cm * cm)


def _style_ax(ax, title):
    ax.set_title(title, loc="left", fontsize=10, fontweight="bold", color=C.BG)
    ax.grid(axis="y", color="#DDDDE6", linewidth=0.7)
    for s in ("top", "right"):
        ax.spines[s].set_visible(False)
    ax.tick_params(labelsize=8)


def _chart_normalized(df_f):
    fig, ax = plt.subplots(figsize=(9, 3.6))
    norm = an.normalized_performance(df_f)
    for i, (comp, g) in enumerate(norm.groupby(C.COMPANY)):
        ax.plot(g[C.DATE], g["Index (base=100)"], label=comp, color=C.color_for(comp, i), linewidth=1.4)
    ax.axhline(100, color="#999999", linewidth=0.8, linestyle=":")
    _style_ax(ax, "Normalised price performance (start of period = 100)")
    ax.legend(fontsize=7, ncol=3, frameon=False)
    return _fig_to_image(fig, 17, 6.8)


def _chart_bar(stats, col, title, fmt="{:.1f}", signed=False, scale=1.0):
    fig, ax = plt.subplots(figsize=(9, 3.0))
    vals = stats[col] / scale
    cols = [(C.RED if v < 0 else "#2F8F9D") if signed else C.RED for v in vals]
    bars = ax.bar(stats[C.COMPANY], vals, color=cols)
    for b, v in zip(bars, vals):
        ax.annotate(fmt.format(v), (b.get_x() + b.get_width() / 2, v), ha="center",
                    va="bottom" if v >= 0 else "top", fontsize=8)
    ax.axhline(0, color="#888888", linewidth=0.8)
    _style_ax(ax, title)
    plt.setp(ax.get_xticklabels(), fontsize=8)
    return _fig_to_image(fig, 17, 5.6)


# --------------------------------------------------------------------------- tables
def _table(data, col_widths=None, header=True, font=8):
    t = Table(data, colWidths=col_widths, repeatRows=1 if header else 0)
    style = [("FONTSIZE", (0, 0), (-1, -1), font), ("FONTNAME", (0, 0), (-1, -1), "Helvetica"),
             ("GRID", (0, 0), (-1, -1), 0.3, colors.HexColor("#CCCCD6")),
             ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
             ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, LIGHT])]
    if header:
        style += [("BACKGROUND", (0, 0), (-1, 0), NAVY), ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
                  ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold")]
    t.setStyle(TableStyle(style))
    return t


def _footer(canvas, doc):
    canvas.saveState()
    canvas.setFont("Helvetica", 7.5)
    canvas.setFillColor(GREY)
    canvas.drawString(2 * cm, 1.1 * cm, "Historical data analysis for educational purposes - not investment advice.")
    canvas.drawRightString(A4[0] - 2 * cm, 1.1 * cm, f"Page {doc.page}")
    canvas.setStrokeColor(RED)
    canvas.setLineWidth(1.2)
    canvas.line(2 * cm, A4[1] - 1.4 * cm, A4[0] - 2 * cm, A4[1] - 1.4 * cm)
    canvas.restoreState()


# --------------------------------------------------------------------------- main builder
def build_pdf(df_full: pd.DataFrame, df_f: pd.DataFrame, start, end,
              ppt_findings: dict[str, str] | None = None,
              quality_summary: pd.DataFrame | None = None,
              source_note: str = "") -> bytes:
    """Return the PDF report as bytes."""
    ss = getSampleStyleSheet()
    h1 = ParagraphStyle("h1", parent=ss["Title"], fontName="Helvetica-Bold", fontSize=22, textColor=NAVY,
                        alignment=TA_LEFT, spaceAfter=4)
    h2 = ParagraphStyle("h2", parent=ss["Heading2"], fontName="Helvetica-Bold", fontSize=13, textColor=RED,
                        spaceBefore=12, spaceAfter=5)
    body = ParagraphStyle("body", parent=ss["BodyText"], fontName="Helvetica", fontSize=9, leading=12.5)
    small = ParagraphStyle("small", parent=body, fontSize=8, textColor=GREY, leading=10.5)
    bullet = ParagraphStyle("bullet", parent=body, leftIndent=12, bulletIndent=2, spaceAfter=2)

    ins = an.generate_insights(df_full, df_f, start, end)
    stats = ins["stats"]
    last_date = df_full[C.DATE].max().date()
    story = []

    # ----- cover / scope
    story += [Paragraph("Stock Market Analysis Report", h1),
              Paragraph(f"Period analysed: {pd.Timestamp(start):%d %b %Y} to {pd.Timestamp(end):%d %b %Y} "
                        f"&nbsp;|&nbsp; Report generated: {date.today():%d %b %Y}", small),
              Spacer(1, 6),
              Paragraph(f"<b>Data currency:</b> the dataset is <b>historical</b>. Its last record is "
                        f"{last_date:%d %b %Y}; it is not live market data. {escape(source_note)}", body),
              Spacer(1, 8)]

    # ----- KPIs
    story.append(Paragraph("1. Key figures", h2))
    kp = [["Records in period", f"{len(df_f):,}"], ["Companies", f"{df_f[C.COMPANY].nunique()}"],
          ["Trading days (max per company)", f"{df_f.groupby(C.COMPANY).size().max():,}"],
          ["Total turnover (all selected)", an.fmt_rs(df_f[C.TURNOVER].sum())]]
    if not stats.empty:
        b, w = stats.loc[stats["Period Return (%)"].idxmax()], stats.loc[stats["Period Return (%)"].idxmin()]
        kp += [["Best period return", f"{b[C.COMPANY]}  {b['Period Return (%)']:+.2f}%"],
               ["Worst period return", f"{w[C.COMPANY]}  {w['Period Return (%)']:+.2f}%"]]
    story.append(_table([["Metric", "Value"]] + kp, [8 * cm, 9 * cm], font=9))

    # ----- company table
    if not stats.empty:
        story.append(Spacer(1, 8))
        rows = [["Company", "Start", "End", "Return %", "Avg daily %", "Volat. %", "Max DD %", "Turnover"]]
        for _, r in stats.sort_values("Period Return (%)", ascending=False).iterrows():
            rows.append([r[C.COMPANY], f"{r['Start Close']:,.1f}", f"{r['End Close']:,.1f}",
                         f"{r['Period Return (%)']:+.2f}", f"{r['Avg Daily Return (%)']:+.3f}",
                         f"{r['Volatility (%)']:.2f}", f"{r['Max Drawdown (%)']:.1f}",
                         an.fmt_rs(r["Total Turnover (Rs.)"])])
        story.append(_table(rows, [3.1 * cm, 1.7 * cm, 1.7 * cm, 1.8 * cm, 2.0 * cm, 1.7 * cm, 1.8 * cm, 3.0 * cm], font=7.5))

        # ----- charts
        story.append(Paragraph("2. Performance and risk charts", h2))
        story.append(_chart_normalized(df_f))
        story.append(Spacer(1, 4))
        story.append(_chart_bar(stats, "Period Return (%)", "Period return (%)", "{:+.1f}%", signed=True))
        story.append(_chart_bar(stats, "Volatility (%)", "Volatility: std-dev of daily returns (%)", "{:.2f}"))
        story.append(_chart_bar(stats, "Total Turnover (Rs.)", "Total turnover (Rs. crore)", "{:,.0f}", scale=1e7))

    # ----- methods
    story.append(Paragraph("3. Methods and definitions", h2))
    for m in [
        "Six company datasets were combined vertically (pandas.concat) with a Company column; column names were "
        "standardised, dates parsed, numeric types converted, records sorted by company and date.",
        "<b>Daily return</b> = % change of Close versus the previous trading day, calculated separately per company.",
        "<b>Period return</b> = last Close in the period / first Close in the period - 1 (the first day's own move "
        "is not included).",
        "<b>Volatility</b> = sample standard deviation of daily returns; <b>max drawdown</b> = largest fall from a "
        "running peak close inside the period.",
        "Missing values were left missing (no imputation). Outliers were flagged, never deleted.",
        "Raw share prices are not directly comparable across companies, so comparisons use returns and a "
        "normalised index (start = 100).",
    ]:
        story.append(Paragraph(m, bullet, bulletText="-"))

    # ----- calculated findings
    story.append(Paragraph("4. Calculated findings (computed from the data)", h2))
    for head, text in ins["bullets"]:
        story.append(Paragraph(f"<b>{escape(head)}:</b> {escape(text)}", bullet, bulletText="-"))
    gains, losses = ins["tables"].get("Largest daily gains"), ins["tables"].get("Largest daily losses")
    if gains is not None and len(gains):
        rows = [["Largest daily gains", "Date", "Return %"]] + [
            [r[C.COMPANY], f"{r[C.DATE]:%Y-%m-%d}", f"{r[C.RET]:+.2f}"] for _, r in gains.head(5).iterrows()]
        rows2 = [["Largest daily losses", "Date", "Return %"]] + [
            [r[C.COMPANY], f"{r[C.DATE]:%Y-%m-%d}", f"{r[C.RET]:+.2f}"] for _, r in losses.head(5).iterrows()]
        story += [Spacer(1, 6), KeepTogether([_table(rows, [6 * cm, 3 * cm, 3 * cm]), Spacer(1, 6),
                                              _table(rows2, [6 * cm, 3 * cm, 3 * cm])])]
    spikes = ins["tables"].get("Volume spikes (>=3x prior 30d avg)")
    if spikes is not None and len(spikes):
        rows = [["Volume spike", "Date", "Shares", "x 30d avg"]] + [
            [r[C.COMPANY], f"{r[C.DATE]:%Y-%m-%d}", f"{r[C.SHARES]:,.0f}", f"{r['Volume vs 30d Avg (x)']:.1f}"]
            for _, r in spikes.head(8).iterrows()]
        story += [Spacer(1, 6), _table(rows, [5 * cm, 3 * cm, 3.5 * cm, 3 * cm])]

    # ----- PPT findings
    story.append(Paragraph("5. Source-reported findings (PowerPoint)", h2))
    story.append(Paragraph("These observations are reproduced as reported in the project PowerPoint. They are "
                           "<b>not</b> independently verified by the calculations above.", small))
    filled = {k: v for k, v in (ppt_findings or {}).items() if str(v).strip()}
    if filled:
        for comp, text in filled.items():
            story.append(Paragraph(f"<b>{escape(comp)}:</b> {escape(text)}", bullet, bulletText="-"))
    else:
        story.append(Paragraph("No PowerPoint observations were provided when this report was generated.", body))

    # ----- data quality
    story.append(Paragraph("6. Data quality and limitations", h2))
    if quality_summary is not None and len(quality_summary):
        flagged = quality_summary[quality_summary["Rows Flagged"] > 0]
        if len(flagged):
            rows = [["Check", "Rows", "Severity"]] + [[r["Check"], str(r["Rows Flagged"]), r["Severity"]]
                                                       for _, r in flagged.iterrows()]
            story.append(_table(rows, [9 * cm, 2.5 * cm, 3.5 * cm]))
        else:
            story.append(Paragraph("No rule-based data-quality flags were raised.", body))
    notes = []
    jumps = df_f[df_f[C.RET] < -40]
    if len(jumps):
        listing = "; ".join(f"{r[C.COMPANY]} {r[C.DATE]:%Y-%m-%d} ({r[C.RET]:.1f}%)" for _, r in jumps.iterrows())
        notes.append("Possible <b>unadjusted corporate action</b>: " + escape(listing) + ". A one-day fall of about "
                     "50% is consistent with a bonus issue or split (not verified). It inflates volatility and "
                     "depresses the period return of the affected company.")
    n_missing = int(df_f[C.DELIV].isna().sum())
    if n_missing:
        notes.append(f"Deliverable quantity is missing for {n_missing} record(s); values were not estimated.")
    notes.append("Historical results do not indicate future performance. This report contains no buy/sell "
                 "recommendations.")
    for m in notes:
        story.append(Paragraph(m, bullet, bulletText="-"))

    buf = io.BytesIO()
    doc = SimpleDocTemplate(buf, pagesize=A4, leftMargin=2 * cm, rightMargin=2 * cm, topMargin=2 * cm,
                            bottomMargin=1.8 * cm, title="Stock Market Analysis Report",
                            author="Stock Market Analysis Dashboard")
    doc.build(story, onFirstPage=_footer, onLaterPages=_footer)
    return buf.getvalue()
