"""Financial analytics, EDA helpers and insight generation (pure pandas/NumPy)."""
from __future__ import annotations

import io
from datetime import date

import numpy as np
import pandas as pd

from . import config as C


# =========================================================================== basics
def add_indicators(df: pd.DataFrame) -> pd.DataFrame:
    """30/90-day moving averages of Close, per company, computed chronologically
    over the *full* history (so values inside a filtered range are not truncated).
    A moving average is only reported once a full window of observations exists."""
    out = df.sort_values([C.COMPANY, C.DATE]).copy()
    grp = out.groupby(C.COMPANY, sort=False)[C.CLOSE]
    out[C.MA30] = grp.transform(lambda s: s.rolling(30, min_periods=30).mean())
    out[C.MA90] = grp.transform(lambda s: s.rolling(90, min_periods=90).mean())
    return out.reset_index(drop=True)


def filter_df(df: pd.DataFrame, companies=None, start=None, end=None) -> pd.DataFrame:
    m = pd.Series(True, index=df.index)
    if companies is not None:
        m &= df[C.COMPANY].isin(list(companies))
    if start is not None:
        m &= df[C.DATE] >= pd.Timestamp(start)
    if end is not None:
        m &= df[C.DATE] <= pd.Timestamp(end)
    return df.loc[m]


def date_bounds(df: pd.DataFrame) -> tuple[date, date]:
    return df[C.DATE].min().date(), df[C.DATE].max().date()


def fmt_num(x, decimals=2) -> str:
    if x is None or (isinstance(x, float) and np.isnan(x)):
        return "n/a"
    return f"{x:,.{decimals}f}"


def fmt_rs(x) -> str:
    """Human-friendly rupee amounts in Indian units (Cr = crore, 1e7)."""
    if x is None or (isinstance(x, float) and np.isnan(x)):
        return "n/a"
    ax = abs(x)
    if ax >= 1e7:
        return f"Rs. {x / 1e7:,.2f} Cr"
    if ax >= 1e5:
        return f"Rs. {x / 1e5:,.2f} L"
    return f"Rs. {x:,.0f}"


def fmt_pct(x, decimals=2, signed=True) -> str:
    if x is None or (isinstance(x, float) and np.isnan(x)):
        return "n/a"
    return f"{x:+.{decimals}f}%" if signed else f"{x:.{decimals}f}%"


# =========================================================================== per-company statistics
def drawdown_series(df: pd.DataFrame) -> pd.DataFrame:
    """Drawdown (%) from the running peak close, per company, within df."""
    d = df.sort_values([C.COMPANY, C.DATE]).copy()
    peak = d.groupby(C.COMPANY, sort=False)[C.CLOSE].cummax()
    d["Drawdown (%)"] = (d[C.CLOSE] / peak - 1) * 100
    return d[[C.COMPANY, C.DATE, C.CLOSE, "Drawdown (%)"]]


def max_drawdown_table(df: pd.DataFrame) -> pd.DataFrame:
    """Maximum drawdown with peak and trough dates, per company.
    Definition: min over t of (Close_t / max(Close_<=t) - 1) inside the selected window."""
    rows = []
    for comp, g in drawdown_series(df).groupby(C.COMPANY, sort=False):
        g = g.reset_index(drop=True)
        if g.empty:
            continue
        i = int(g["Drawdown (%)"].idxmin())
        peak_idx = int(g.loc[:i, C.CLOSE].idxmax())
        rows.append({C.COMPANY: comp,
                     "Max Drawdown (%)": g.loc[i, "Drawdown (%)"],
                     "Peak Date": g.loc[peak_idx, C.DATE], "Peak Close": g.loc[peak_idx, C.CLOSE],
                     "Trough Date": g.loc[i, C.DATE], "Trough Close": g.loc[i, C.CLOSE]})
    return pd.DataFrame(rows)


def company_stats(df: pd.DataFrame) -> pd.DataFrame:
    """One consistent set of definitions for every company (used on all pages).

    * Period return  = last Close / first Close in the window - 1.
    * Daily return   = % change of Close vs. the previous trading day (full history).
    * Volatility     = sample std-dev of daily returns (annualised x sqrt(252)).
    * Max drawdown   = worst fall from a running peak close inside the window.
    """
    rows = []
    for comp, g in df.sort_values([C.COMPANY, C.DATE]).groupby(C.COMPANY, sort=False):
        g = g.dropna(subset=[C.CLOSE])
        if g.empty:
            continue
        r = g[C.RET].dropna()
        first, last = g[C.CLOSE].iloc[0], g[C.CLOSE].iloc[-1]
        rows.append({
            C.COMPANY: comp,
            "Start Date": g[C.DATE].iloc[0], "End Date": g[C.DATE].iloc[-1],
            "Start Close": first, "End Close": last,
            "Period Return (%)": (last / first - 1) * 100 if first else np.nan,
            "Avg Daily Return (%)": r.mean() if len(r) else np.nan,
            "Volatility (%)": r.std() if len(r) > 1 else np.nan,
            "Ann. Volatility (%)": r.std() * np.sqrt(C.TRADING_DAYS_PER_YEAR) if len(r) > 1 else np.nan,
            "Highest Close": g[C.CLOSE].max(), "Lowest Close": g[C.CLOSE].min(),
            "Total Turnover (Rs.)": g[C.TURNOVER].sum(),
            "Avg Daily Turnover (Rs.)": g[C.TURNOVER].mean(),
            "Total Shares Traded": g[C.SHARES].sum(),
            "Avg Daily Shares": g[C.SHARES].mean(),
            "Avg Daily Trades": g[C.TRADES].mean(),
            "Avg Delivery (%)": g[C.DELIV_PCT].mean(),
            "Positive Days": int((r > 0).sum()), "Negative Days": int((r < 0).sum()),
            "Trading Days": len(g),
        })
    out = pd.DataFrame(rows)
    if out.empty:
        return out
    dd = max_drawdown_table(df)[[C.COMPANY, "Max Drawdown (%)"]]
    return out.merge(dd, on=C.COMPANY, how="left")


def normalized_performance(df: pd.DataFrame) -> pd.DataFrame:
    """Close rebased to 100 at each company's first observation in the window."""
    d = df.sort_values([C.COMPANY, C.DATE]).dropna(subset=[C.CLOSE]).copy()
    base = d.groupby(C.COMPANY, sort=False)[C.CLOSE].transform("first")
    d["Index (base=100)"] = d[C.CLOSE] / base * 100
    return d


def return_correlation(df: pd.DataFrame) -> pd.DataFrame:
    wide = df.pivot_table(index=C.DATE, columns=C.COMPANY, values=C.RET)
    return wide.corr()


def overview_kpis(df_all: pd.DataFrame, df_sel: pd.DataFrame) -> dict:
    """KPIs for the Market Overview page. df_sel = one company within date range."""
    r = df_sel[C.RET].dropna()
    last = df_sel.sort_values(C.DATE).iloc[-1] if len(df_sel) else None
    return {
        "total_records": len(df_all), "selected_records": len(df_sel),
        "companies": df_all[C.COMPANY].nunique(),
        "latest_date": df_all[C.DATE].max().date(),
        "latest_close": float(last[C.CLOSE]) if last is not None else np.nan,
        "latest_close_date": last[C.DATE].date() if last is not None else None,
        "avg_return": r.mean() if len(r) else np.nan,
        "turnover": df_sel[C.TURNOVER].sum(),
        "high_close": df_sel[C.CLOSE].max(), "low_close": df_sel[C.CLOSE].min(),
        "high_date": df_sel.loc[df_sel[C.CLOSE].idxmax(), C.DATE].date() if len(df_sel) else None,
        "low_date": df_sel.loc[df_sel[C.CLOSE].idxmin(), C.DATE].date() if len(df_sel) else None,
        "pos_days": int((r > 0).sum()), "neg_days": int((r < 0).sum()),
        "flat_days": int((r == 0).sum()),
    }


def top_daily_moves(df: pd.DataFrame, n=5, ascending=False, with_company=True) -> pd.DataFrame:
    cols = ([C.COMPANY] if with_company else []) + [C.DATE, C.CLOSE, C.RET]
    d = df.dropna(subset=[C.RET])
    d = d.nsmallest(n, C.RET) if ascending else d.nlargest(n, C.RET)
    return d[cols].reset_index(drop=True)


# =========================================================================== EDA
def info_text(df: pd.DataFrame) -> str:
    buf = io.StringIO()
    df.info(buf=buf)
    return buf.getvalue()


def missing_by_column(df: pd.DataFrame) -> pd.DataFrame:
    m = df.isna().sum()
    return pd.DataFrame({"Column": m.index, "Missing": m.values,
                         "Missing (%)": (m.values / max(len(df), 1) * 100).round(3)})


def missing_by_company(df: pd.DataFrame) -> pd.DataFrame:
    """Counts of missing values per company and column (only columns with gaps)."""
    miss = df.drop(columns=[C.COMPANY]).isna().groupby(df[C.COMPANY]).sum()
    return miss.loc[:, miss.sum() > 0]


def coverage_table(df: pd.DataFrame) -> pd.DataFrame:
    g = df.groupby(C.COMPANY)[C.DATE]
    out = pd.DataFrame({"First Date": g.min(), "Last Date": g.max(), "Rows": g.size(),
                        "Unique Dates": g.nunique()}).reset_index()
    out["Calendar Span (days)"] = (out["Last Date"] - out["First Date"]).dt.days
    return out


def duplicate_report(df: pd.DataFrame) -> dict:
    return {"exact": int(df.duplicated().sum()),
            "company_date": int(df.duplicated(subset=[C.COMPANY, C.DATE]).sum())}


def iqr_outliers(df: pd.DataFrame, cols: list[str]) -> pd.DataFrame:
    """IQR (1.5x) outlier summary per company and column. Outliers are only
    *flagged* – in financial data they are frequently genuine market events."""
    rows = []
    for comp, g in df.groupby(C.COMPANY):
        for col in cols:
            s = g[col].dropna()
            if len(s) < 4:
                continue
            q1, q3 = s.quantile(.25), s.quantile(.75)
            iqr = q3 - q1
            lo, hi = q1 - 1.5 * iqr, q3 + 1.5 * iqr
            n_out = int(((s < lo) | (s > hi)).sum())
            rows.append({C.COMPANY: comp, "Column": col, "Q1": q1, "Q3": q3, "IQR": iqr,
                         "Lower Fence": lo, "Upper Fence": hi, "Outliers": n_out,
                         "Outliers (%)": n_out / len(s) * 100})
    return pd.DataFrame(rows)


def outlier_rows(df: pd.DataFrame, company: str, col: str) -> pd.DataFrame:
    g = df[df[C.COMPANY] == company]
    s = g[col].dropna()
    q1, q3 = s.quantile(.25), s.quantile(.75)
    iqr = q3 - q1
    return g[(g[col] < q1 - 1.5 * iqr) | (g[col] > q3 + 1.5 * iqr)][[C.COMPANY, C.DATE, col]]


def quality_checks(df: pd.DataFrame, today: date | None = None) -> tuple[pd.DataFrame, dict]:
    """Rule-based data-quality checks.

    Returns (summary table, {check name: boolean mask}).  Severity:
      * 'Anomaly'      – impossible / inconsistent values (should be investigated)
      * 'Review'       – unusual but frequently valid market observations
    """
    today = pd.Timestamp(today or date.today())
    masks: dict[str, tuple[pd.Series, str, str]] = {}
    idx = df.index
    f = lambda s: s.fillna(False)  # noqa: E731

    masks["Dates in the future"] = (df[C.DATE] > today, "Anomaly",
                                    "Date later than today.")
    masks["Duplicate Company+Date"] = (df.duplicated(subset=[C.COMPANY, C.DATE], keep=False), "Anomaly",
                                       "Same company and date appears more than once.")
    masks["Weekend trading dates"] = (df[C.DATE].dt.dayofweek >= 5, "Review",
                                      "Saturday/Sunday dates; Indian exchanges hold occasional special sessions.")
    for col in C.PRICE_COLS:
        masks[f"Zero/negative {col}"] = (f(df[col] <= 0), "Anomaly", "Prices must be positive.")
    for col in (C.SHARES, C.TRADES, C.TURNOVER):
        masks[f"Zero/negative {col}"] = (f(df[col] <= 0), "Anomaly", "Activity measures should be positive.")
    masks["High < Low"] = (f(df[C.HIGH] < df[C.LOW]), "Anomaly", "High price below low price.")
    masks["High below Open/Close"] = (f(df[C.HIGH] < df[[C.OPEN, C.CLOSE]].max(axis=1)), "Anomaly",
                                      "High must be >= Open and Close.")
    masks["Low above Open/Close"] = (f(df[C.LOW] > df[[C.OPEN, C.CLOSE]].min(axis=1)), "Anomaly",
                                     "Low must be <= Open and Close.")
    masks["WAP outside Low-High"] = (f((df[C.WAP] < df[C.LOW] - 0.01) | (df[C.WAP] > df[C.HIGH] + 0.01)), "Anomaly",
                                     "Weighted average price should lie within the day's range.")
    masks["Spread High-Low mismatch"] = (f((df[C.HIGH] - df[C.LOW] - df[C.SPREAD_HL]).abs() > 0.011), "Anomaly",
                                         "Spread column differs from High - Low.")
    masks["Spread Close-Open mismatch"] = (f((df[C.CLOSE] - df[C.OPEN] - df[C.SPREAD_CO]).abs() > 0.011), "Anomaly",
                                           "Spread column differs from Close - Open.")
    masks["Deliverable > traded shares"] = (f(df[C.DELIV] > df[C.SHARES]), "Anomaly",
                                            "Deliverable quantity cannot exceed traded quantity.")
    masks["Delivery % outside 0-100"] = (f((df[C.DELIV_PCT] < 0) | (df[C.DELIV_PCT] > 100)), "Anomaly",
                                         "Percentage must be between 0 and 100.")
    masks["Missing deliverable quantity"] = (df[C.DELIV].isna(), "Review",
                                             "Not reported for that day; left missing (not imputed).")
    masks["|Daily return| > 15%"] = (f(df[C.RET].abs() > 15), "Review",
                                     "Very large one-day move. Can be a genuine event, or an unadjusted "
                                     "corporate action (e.g. bonus/split) – verify before excluding.")

    rows = [{"Check": k, "Rows Flagged": int(v[0].sum()), "Severity": v[1], "Meaning": v[2]}
            for k, v in masks.items()]
    summary = pd.DataFrame(rows)
    return summary, {k: v[0].reindex(idx, fill_value=False) for k, v in masks.items()}


def column_quality_summary(df: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for col in df.columns:
        s = df[col]
        row = {"Column": col, "Type": str(s.dtype), "Non-null": int(s.notna().sum()),
               "Missing": int(s.isna().sum()), "Missing (%)": round(s.isna().mean() * 100, 3),
               "Unique": int(s.nunique())}
        if pd.api.types.is_numeric_dtype(s):
            x = s.dropna()
            q1, q3 = (x.quantile(.25), x.quantile(.75)) if len(x) else (np.nan, np.nan)
            iqr = q3 - q1
            row.update({"Min": x.min() if len(x) else np.nan, "Max": x.max() if len(x) else np.nan,
                        "IQR Outliers": int(((x < q1 - 1.5 * iqr) | (x > q3 + 1.5 * iqr)).sum()) if len(x) else 0})
        rows.append(row)
    return pd.DataFrame(rows)


def stats_table(df: pd.DataFrame, cols: list[str]) -> pd.DataFrame:
    """Mean/median/std/min/max per company for the chosen columns."""
    agg = df.groupby(C.COMPANY)[cols].agg(["mean", "median", "std", "min", "max"])
    agg.columns = [f"{a} | {b}" for a, b in agg.columns]
    return agg.reset_index()


def activity_table(df: pd.DataFrame) -> pd.DataFrame:
    g = df.groupby(C.COMPANY)
    return pd.DataFrame({
        "Avg Shares / Day": g[C.SHARES].mean(), "Avg Trades / Day": g[C.TRADES].mean(),
        "Avg Turnover / Day (Rs.)": g[C.TURNOVER].mean(),
        "Avg Delivery (%)": g[C.DELIV_PCT].mean(),
        "Avg Deliverable Qty": g[C.DELIV].mean(),
    }).reset_index()


# =========================================================================== insights
def volume_spikes(df_full: pd.DataFrame, start=None, end=None, factor=3.0, n=15) -> pd.DataFrame:
    """Days where traded shares >= factor x the *previous* 30-day average."""
    d = df_full.sort_values([C.COMPANY, C.DATE]).copy()
    prev_avg = d.groupby(C.COMPANY, sort=False)[C.SHARES].transform(
        lambda s: s.shift(1).rolling(30, min_periods=30).mean())
    d["Volume vs 30d Avg (x)"] = d[C.SHARES] / prev_avg
    d = filter_df(d, None, start, end)
    d = d[d["Volume vs 30d Avg (x)"] >= factor]
    return d.sort_values("Volume vs 30d Avg (x)", ascending=False)[
        [C.COMPANY, C.DATE, C.SHARES, "Volume vs 30d Avg (x)", C.RET]].head(n).reset_index(drop=True)


def generate_insights(df_full: pd.DataFrame, df_f: pd.DataFrame, start, end) -> dict:
    """Data-driven findings for the selected window. Every number is computed here."""
    stats = company_stats(df_f)
    out: dict = {"stats": stats, "bullets": [], "tables": {}}
    if stats.empty:
        return out
    b = out["bullets"]
    best = stats.loc[stats["Period Return (%)"].idxmax()]
    worst = stats.loc[stats["Period Return (%)"].idxmin()]
    b.append(("Best performer", f"{best[C.COMPANY]} returned {best['Period Return (%)']:+.2f}% "
              f"(Close {best['Start Close']:,.2f} → {best['End Close']:,.2f})."))
    b.append(("Worst performer", f"{worst[C.COMPANY]} returned {worst['Period Return (%)']:+.2f}% "
              f"(Close {worst['Start Close']:,.2f} → {worst['End Close']:,.2f})."))
    top_t = stats.loc[stats["Total Turnover (Rs.)"].idxmax()]
    b.append(("Highest turnover", f"{top_t[C.COMPANY]} – total traded value {fmt_rs(top_t['Total Turnover (Rs.)'])}."))

    d = df_f.dropna(subset=[C.RET])
    if len(d):
        up, dn = d.loc[d[C.RET].idxmax()], d.loc[d[C.RET].idxmin()]
        b.append(("Largest daily gain", f"{up[C.COMPANY]} on {up[C.DATE]:%Y-%m-%d}: {up[C.RET]:+.2f}%."))
        b.append(("Largest daily loss", f"{dn[C.COMPANY]} on {dn[C.DATE]:%Y-%m-%d}: {dn[C.RET]:+.2f}%. "
                  "Moves near -50% may reflect an unadjusted bonus/split rather than a real price fall."
                  if dn[C.RET] < -40 else f"{dn[C.COMPANY]} on {dn[C.DATE]:%Y-%m-%d}: {dn[C.RET]:+.2f}%."))
    vol = stats.dropna(subset=["Volatility (%)"])
    if len(vol):
        hi, lo = vol.loc[vol["Volatility (%)"].idxmax()], vol.loc[vol["Volatility (%)"].idxmin()]
        b.append(("Volatility", f"Highest: {hi[C.COMPANY]} ({hi['Volatility (%)']:.2f}% daily std-dev); "
                  f"lowest: {lo[C.COMPANY]} ({lo['Volatility (%)']:.2f}%). Note: the day-to-day figures include "
                  "any one-off corporate-action jumps."))
    dd = stats.loc[stats["Max Drawdown (%)"].idxmin()]
    b.append(("Deepest drawdown", f"{dd[C.COMPANY]} fell {dd['Max Drawdown (%)']:.2f}% from a running peak."))

    out["tables"]["Company summary"] = stats
    out["tables"]["Largest daily gains"] = top_daily_moves(d, 10, ascending=False)
    out["tables"]["Largest daily losses"] = top_daily_moves(d, 10, ascending=True)
    out["tables"]["Max drawdown detail"] = max_drawdown_table(df_f)
    out["tables"]["Volume spikes (>=3x prior 30d avg)"] = volume_spikes(df_full, start, end)
    return out


def verify_period_returns(df_f: pd.DataFrame) -> pd.DataFrame:
    """Independent re-computation of each company's period return using DuckDB SQL
    (arg_min/arg_max) to cross-check the pandas figures shown in the app."""
    from . import sql_engine as SE   # local import avoids a circular dependency
    stats = company_stats(df_f)[[C.COMPANY, "Period Return (%)"]]
    sql = ("SELECT company, (arg_max(close_price, trade_date) / arg_min(close_price, trade_date) - 1) * 100 "
           "AS sql_return FROM stock_data GROUP BY company")
    res = SE.run_query(df_f, sql)
    if res.error:
        raise RuntimeError(res.error)
    m = stats.merge(res.df.rename(columns={"company": C.COMPANY}), on=C.COMPANY)
    m["Pandas Return (%)"] = m["Period Return (%)"]
    m["SQL Return (%)"] = m["sql_return"].astype(float)
    m["Abs Difference"] = (m["Pandas Return (%)"] - m["SQL Return (%)"]).abs()
    return m[[C.COMPANY, "Pandas Return (%)", "SQL Return (%)", "Abs Difference"]]
