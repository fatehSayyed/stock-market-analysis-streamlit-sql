"""SQL question bank (28 questions) executed by DuckDB against table `stock_data`.

Placeholders in `sql`:  {company}  {start}  {end}   (filled from the UI parameters)
"""
from __future__ import annotations

from datetime import date

# Shared window clauses keep the longer queries readable.
_W30 = "WINDOW w AS (PARTITION BY company ORDER BY trade_date ROWS BETWEEN 29 PRECEDING AND CURRENT ROW)"
_W90 = "WINDOW w AS (PARTITION BY company ORDER BY trade_date ROWS BETWEEN 89 PRECEDING AND CURRENT ROW)"


def _q(id_, level, title, description, concept, sql, explanation, params=()):
    return {"id": id_, "level": level, "title": title, "description": description,
            "concept": concept, "sql": sql.strip("\n"), "explanation": explanation,
            "params": list(params)}


QUESTIONS: list[dict] = [
    # ------------------------------------------------------------------ Beginner
    _q(1, "Beginner", "First 10 records", "Display the first 10 records of the dataset.",
       "SELECT, ORDER BY, LIMIT",
       """SELECT *
FROM stock_data
ORDER BY company, trade_date
LIMIT 10;""",
       "ORDER BY makes 'first' well defined (otherwise row order is not guaranteed); LIMIT keeps 10 rows."),
    _q(2, "Beginner", "Count total records", "Count how many rows the table holds.",
       "COUNT(*)",
       "SELECT COUNT(*) AS total_records\nFROM stock_data;",
       "COUNT(*) counts rows regardless of NULLs."),
    _q(3, "Beginner", "Distinct companies", "List every company in the dataset.",
       "DISTINCT",
       "SELECT DISTINCT company\nFROM stock_data\nORDER BY company;",
       "DISTINCT removes repeated values; ORDER BY gives a stable listing."),
    _q(4, "Beginner", "Minimum and maximum dates", "Find the earliest and latest trading date.",
       "MIN, MAX on dates",
       "SELECT MIN(trade_date) AS first_date,\n       MAX(trade_date) AS last_date\nFROM stock_data;",
       "MIN/MAX work on DATE columns. The last date is the last *historical* record, not today."),
    _q(5, "Beginner", "Highest closing price per company", "Highest close recorded for each company.",
       "GROUP BY, MAX",
       """SELECT company,
       MAX(close_price) AS highest_close
FROM stock_data
GROUP BY company
ORDER BY highest_close DESC;""",
       "GROUP BY collapses rows per company; MAX is evaluated inside each group."),
    _q(6, "Beginner", "Average closing price by company", "Average close for each company.",
       "GROUP BY, AVG, ROUND",
       """SELECT company,
       ROUND(AVG(close_price), 2) AS avg_close
FROM stock_data
GROUP BY company
ORDER BY avg_close DESC;""",
       "AVG ignores NULLs. Raw price levels differ by company, so averages are not performance measures."),
    _q(7, "Beginner", "Total turnover by company", "Total traded value (Rs.) per company.",
       "GROUP BY, SUM",
       """SELECT company,
       SUM(total_turnover) AS total_turnover_rs
FROM stock_data
GROUP BY company
ORDER BY total_turnover_rs DESC;""",
       "SUM adds the daily traded value across all days of each company."),
    _q(8, "Beginner", "Missing delivery quantities", "Rows where deliverable quantity is missing.",
       "IS NULL",
       """SELECT company, trade_date, no_of_shares, deliverable_quantity, pct_deliverable
FROM stock_data
WHERE deliverable_quantity IS NULL
ORDER BY company, trade_date;""",
       "Use IS NULL (not = NULL) to test for missing values. Missing values are left missing, never filled."),

    # ------------------------------------------------------------------ Intermediate
    _q(9, "Intermediate", "Top 5 turnover dates (selected company)",
       "Five dates with the highest turnover for the selected company.",
       "WHERE, ORDER BY DESC, LIMIT",
       """SELECT trade_date, company, total_turnover, no_of_shares, close_price
FROM stock_data
WHERE company = '{company}'
ORDER BY total_turnover DESC
LIMIT 5;""",
       "Filter first, sort descending, keep the top rows. Change the company name to explore others.",
       ("company",)),
    _q(10, "Intermediate", "Rank companies by average close", "Rank companies by their average closing price.",
       "Aggregate + window RANK()",
       """SELECT company,
       ROUND(AVG(close_price), 2) AS avg_close,
       RANK() OVER (ORDER BY AVG(close_price) DESC) AS price_rank
FROM stock_data
GROUP BY company
ORDER BY price_rank;""",
       "Window functions run after GROUP BY, so RANK() can order the aggregated averages."),
    _q(11, "Intermediate", "Monthly average close per company", "Average closing price per company and month.",
       "DATE_TRUNC, GROUP BY",
       """SELECT company,
       DATE_TRUNC('month', trade_date)::DATE AS month,
       ROUND(AVG(close_price), 2) AS avg_close
FROM stock_data
GROUP BY company, month
ORDER BY company, month;""",
       "DATE_TRUNC('month', ...) maps each date to the first day of its month so rows can be grouped."),
    _q(12, "Intermediate", "Monthly total turnover per company", "Total turnover per company and month.",
       "DATE_TRUNC, SUM",
       """SELECT company,
       DATE_TRUNC('month', trade_date)::DATE AS month,
       SUM(total_turnover) AS monthly_turnover_rs
FROM stock_data
GROUP BY company, month
ORDER BY company, month;""",
       "Same pattern as Q11 with SUM instead of AVG."),
    _q(13, "Intermediate", "Top 10 highest-volume days", "The ten trading days with the most shares traded (any company).",
       "ORDER BY, LIMIT",
       """SELECT company, trade_date, no_of_shares, total_turnover, close_price
FROM stock_data
ORDER BY no_of_shares DESC
LIMIT 10;""",
       "Volume is compared across companies in shares, which depends on each company's share count/price."),
    _q(14, "Intermediate", "Opening vs closing prices", "Compare each company's average open and close and how often it closed above the open.",
       "Conditional aggregation (CASE)",
       """SELECT company,
       ROUND(AVG(open_price), 2)  AS avg_open,
       ROUND(AVG(close_price), 2) AS avg_close,
       ROUND(AVG(close_price - open_price), 2) AS avg_close_minus_open,
       ROUND(100.0 * SUM(CASE WHEN close_price > open_price THEN 1 ELSE 0 END) / COUNT(*), 1)
           AS pct_days_close_above_open
FROM stock_data
GROUP BY company
ORDER BY pct_days_close_above_open DESC;""",
       "CASE inside SUM counts rows meeting a condition; dividing by COUNT(*) gives a percentage."),
    _q(15, "Intermediate", "Close above 30-day moving average", "Days when the close was above its 30-day moving average (full 30-day windows only).",
       "CTE + window AVG, filter on window result",
       f"""WITH ma AS (
    SELECT company, trade_date, close_price,
           AVG(close_price) OVER w AS ma30,
           COUNT(*) OVER w AS window_size
    FROM stock_data
    {_W30}
)
SELECT company, trade_date, close_price, ROUND(ma30, 2) AS ma30
FROM ma
WHERE window_size = 30 AND close_price > ma30
ORDER BY company, trade_date;""",
       "Window results cannot be used in WHERE directly, so a CTE computes them first. window_size = 30 avoids partial windows."),
    _q(16, "Intermediate", "Daily returns with window functions", "Daily % return per company using LAG().",
       "LAG(), PARTITION BY, ORDER BY",
       """SELECT company, trade_date, close_price,
       ROUND((close_price / LAG(close_price) OVER (PARTITION BY company ORDER BY trade_date) - 1) * 100, 4)
           AS daily_return_pct
FROM stock_data
ORDER BY company, trade_date;""",
       "LAG fetches the previous trading day's close within the same company. The first day has no return (NULL)."),
    _q(17, "Intermediate", "Identify duplicate records", "Find company/date combinations that appear more than once.",
       "GROUP BY ... HAVING",
       """SELECT company, trade_date, COUNT(*) AS occurrences
FROM stock_data
GROUP BY company, trade_date
HAVING COUNT(*) > 1
ORDER BY occurrences DESC, company, trade_date;""",
       "HAVING filters groups after aggregation. An empty result means there are no duplicate company/date keys."),
    _q(18, "Intermediate", "Average trading volume by company", "Compare average daily shares traded and trades per company.",
       "AVG on several columns",
       """SELECT company,
       ROUND(AVG(no_of_shares), 0) AS avg_daily_shares,
       ROUND(AVG(no_of_trades), 0) AS avg_daily_trades
FROM stock_data
GROUP BY company
ORDER BY avg_daily_shares DESC;""",
       "Several aggregates can be computed in one pass over each group."),

    # ------------------------------------------------------------------ Advanced
    _q(19, "Advanced", "30-day moving average", "30-day moving average of the close (reported only for full windows).",
       "Window frame ROWS BETWEEN, named WINDOW",
       f"""SELECT company, trade_date, close_price,
       CASE WHEN COUNT(*) OVER w = 30 THEN ROUND(AVG(close_price) OVER w, 2) END AS ma30
FROM stock_data
{_W30}
ORDER BY company, trade_date;""",
       "ROWS BETWEEN 29 PRECEDING AND CURRENT ROW covers 30 trading days. The CASE leaves the first 29 days NULL."),
    _q(20, "Advanced", "90-day moving average", "90-day moving average of the close (reported only for full windows).",
       "Window frame with a longer window",
       f"""SELECT company, trade_date, close_price,
       CASE WHEN COUNT(*) OVER w = 90 THEN ROUND(AVG(close_price) OVER w, 2) END AS ma90
FROM stock_data
{_W90}
ORDER BY company, trade_date;""",
       "Identical to Q19 with an 89-row look-back."),
    _q(21, "Advanced", "RANK vs DENSE_RANK of daily returns", "On each date, rank the companies by their daily return.",
       "RANK(), DENSE_RANK(), PARTITION BY date",
       """SELECT trade_date, company,
       ROUND(daily_return_pct, 4) AS daily_return_pct,
       RANK()       OVER (PARTITION BY trade_date ORDER BY daily_return_pct DESC) AS rnk,
       DENSE_RANK() OVER (PARTITION BY trade_date ORDER BY daily_return_pct DESC) AS dense_rnk
FROM stock_data
WHERE daily_return_pct IS NOT NULL
ORDER BY trade_date, rnk;""",
       "RANK leaves gaps after ties (1,1,3); DENSE_RANK does not (1,1,2). They only differ when returns tie exactly."),
    _q(22, "Advanced", "Highest and lowest close dates", "Date and value of each company's highest and lowest close.",
       "ROW_NUMBER + conditional aggregation",
       """WITH ranked AS (
    SELECT company, trade_date, close_price,
           ROW_NUMBER() OVER (PARTITION BY company ORDER BY close_price DESC, trade_date) AS hi_rank,
           ROW_NUMBER() OVER (PARTITION BY company ORDER BY close_price ASC,  trade_date) AS lo_rank
    FROM stock_data
)
SELECT company,
       MAX(CASE WHEN hi_rank = 1 THEN trade_date  END) AS highest_close_date,
       MAX(CASE WHEN hi_rank = 1 THEN close_price END) AS highest_close,
       MAX(CASE WHEN lo_rank = 1 THEN trade_date  END) AS lowest_close_date,
       MAX(CASE WHEN lo_rank = 1 THEN close_price END) AS lowest_close
FROM ranked
GROUP BY company
ORDER BY company;""",
       "ROW_NUMBER = 1 picks exactly one row per direction (earliest date wins ties). CASE + MAX pivots them into one row."),
    _q(23, "Advanced", "Cumulative turnover", "Running total of turnover per company.",
       "SUM() OVER with UNBOUNDED PRECEDING",
       """SELECT company, trade_date, total_turnover,
       SUM(total_turnover) OVER (
           PARTITION BY company ORDER BY trade_date
           ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW) AS cumulative_turnover
FROM stock_data
ORDER BY company, trade_date;""",
       "A frame that starts at the first row turns SUM into a running total."),
    _q(24, "Advanced", "Running maximum close", "Highest close seen so far (all-time high to date) per company.",
       "MAX() OVER running frame",
       """SELECT company, trade_date, close_price,
       MAX(close_price) OVER (
           PARTITION BY company ORDER BY trade_date
           ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW) AS running_max_close
FROM stock_data
ORDER BY company, trade_date;""",
       "Useful for drawdowns: close / running_max_close - 1."),
    _q(25, "Advanced", "Consecutive positive / negative streaks", "Runs of at least 3 consecutive trading days with the same return direction.",
       "Gaps-and-islands with two ROW_NUMBERs",
       """WITH r AS (
    SELECT company, trade_date, daily_return_pct,
           CASE WHEN daily_return_pct > 0 THEN 'Positive'
                WHEN daily_return_pct < 0 THEN 'Negative'
                ELSE 'Flat' END AS direction
    FROM stock_data
    WHERE daily_return_pct IS NOT NULL
),
g AS (
    SELECT *,
           ROW_NUMBER() OVER (PARTITION BY company ORDER BY trade_date)
         - ROW_NUMBER() OVER (PARTITION BY company, direction ORDER BY trade_date) AS grp
    FROM r
)
SELECT company, direction,
       MIN(trade_date) AS streak_start,
       MAX(trade_date) AS streak_end,
       COUNT(*)        AS trading_days
FROM g
WHERE direction <> 'Flat'
GROUP BY company, direction, grp
HAVING COUNT(*) >= 3
ORDER BY trading_days DESC, company, streak_start
LIMIT 100;""",
       "Within an unbroken run the difference of the two row numbers is constant, so it identifies the run. Streaks count trading days, not calendar days."),
    _q(26, "Advanced", "Monthly returns (first vs last observation)", "Return from the first to the last valid close of each month.",
       "arg_min / arg_max (DuckDB)",
       """SELECT company,
       DATE_TRUNC('month', trade_date)::DATE AS month,
       arg_min(close_price, trade_date) AS first_close,
       arg_max(close_price, trade_date) AS last_close,
       ROUND((arg_max(close_price, trade_date) / arg_min(close_price, trade_date) - 1) * 100, 2)
           AS monthly_return_pct
FROM stock_data
WHERE close_price IS NOT NULL
GROUP BY company, month
ORDER BY company, month;""",
       "arg_min(x, d) returns x on the earliest d. This measures first-to-last close *within* the month, so it excludes the overnight move from the previous month's last close."),
    _q(27, "Advanced", "Volatility of daily returns", "Standard deviation of daily returns per company (also annualised).",
       "STDDEV_SAMP, SQRT",
       """SELECT company,
       COUNT(daily_return_pct) AS observations,
       ROUND(AVG(daily_return_pct), 4) AS avg_daily_return_pct,
       ROUND(STDDEV_SAMP(daily_return_pct), 4) AS daily_volatility_pct,
       ROUND(STDDEV_SAMP(daily_return_pct) * SQRT(252), 2) AS annualised_volatility_pct
FROM stock_data
GROUP BY company
ORDER BY daily_volatility_pct DESC;""",
       "Annualised = daily x sqrt(252 trading days). One-off corporate-action jumps (e.g. a bonus) inflate this measure."),
    _q(28, "Advanced", "Top performers over a date range", "Rank companies by return between two dates (first to last close in range).",
       "CTE + arg_min/arg_max + RANK()",
       """WITH r AS (
    SELECT company,
           MIN(trade_date) AS first_date,
           MAX(trade_date) AS last_date,
           arg_min(close_price, trade_date) AS start_close,
           arg_max(close_price, trade_date) AS end_close
    FROM stock_data
    WHERE trade_date BETWEEN DATE '{start}' AND DATE '{end}'
    GROUP BY company
)
SELECT company, first_date, last_date, start_close, end_close,
       ROUND((end_close / start_close - 1) * 100, 2) AS period_return_pct,
       RANK() OVER (ORDER BY end_close / start_close DESC) AS performance_rank
FROM r
ORDER BY performance_rank;""",
       "Edit the dates in the query to test other periods. Prices may be unadjusted for splits/bonus issues.",
       ("date_range",)),
]

LEVELS = ["Beginner", "Intermediate", "Advanced"]
BY_ID = {q["id"]: q for q in QUESTIONS}


def render_sql(q: dict, company: str = "TCS", start: date | str = "2015-01-01",
               end: date | str = "2018-07-31") -> str:
    """Fill the placeholders of a question's SQL template."""
    safe_company = str(company).replace("'", "''")
    return (q["sql"].replace("{company}", safe_company)
            .replace("{start}", str(start)).replace("{end}", str(end)))


def label(q: dict) -> str:
    return f"Q{q['id']:02d} · {q['level']} · {q['title']}"


def build_sql_script(company: str, start, end) -> str:
    """The complete question bank as a documented, runnable .sql file."""
    head = f"""-- ===========================================================================
-- Stock Market Analysis - SQL script (DuckDB dialect)
-- Table: stock_data(trade_date DATE, company, open_price, high_price, low_price,
--        close_price, wap, no_of_shares, no_of_trades, total_turnover,
--        deliverable_quantity, pct_deliverable, spread_high_low,
--        spread_close_open, daily_return_pct)
-- Parameters used: company = '{company}', range = {start} .. {end}
-- Notes: data is historical (not live); prices may be unadjusted for corporate
--        actions; missing values are left as NULL.
-- ==========================================================================="""
    parts = [head]
    for lvl in LEVELS:
        parts.append(f"\n-- ############ {lvl.upper()} ############")
        for q in QUESTIONS:
            if q["level"] != lvl:
                continue
            parts.append(f"\n-- Q{q['id']}. {q['title']}: {q['description']}\n"
                         f"-- Concept: {q['concept']}\n{render_sql(q, company, start, end)}")
    return "\n".join(parts) + "\n"
