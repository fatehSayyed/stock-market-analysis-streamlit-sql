"""Streamlit UI helpers: global CSS, KPI cards, panels, shared filter bar."""
from __future__ import annotations

from datetime import date
from html import escape

import pandas as pd
import streamlit as st

from . import config as C

CSS = f"""
<style>
html, body, [data-testid="stApp"] {{ background:{C.BG}; color:{C.TEXT};
  font-family:'Inter','Segoe UI',system-ui,-apple-system,sans-serif; }}
#MainMenu, footer {{ visibility:hidden; }}
[data-testid="stHeader"] {{ background:transparent; }}
.block-container {{ padding-top:2.2rem; padding-bottom:2rem; max-width:1500px; }}
h1 {{ font-size:1.45rem !important; font-weight:650 !important; letter-spacing:.2px; margin-bottom:.1rem; }}
h2 {{ font-size:1.1rem !important; font-weight:600 !important; }}
h3 {{ font-size:.95rem !important; font-weight:600 !important; }}
p, li, label, .stMarkdown {{ font-size:.9rem; }}
[data-testid="stSidebar"] {{ background:#0C0C19; border-right:1px solid {C.BORDER}; }}
[data-testid="stSidebar"] .block-container {{ padding-top:1rem; }}
.brand {{ font-weight:700; font-size:1.05rem; letter-spacing:.5px; padding:.2rem 0 .8rem 0; }}
.brand span {{ color:{C.RED}; }}
.side-note {{ color:{C.MUTED}; font-size:.74rem; line-height:1.45; border-top:1px solid {C.BORDER};
  padding-top:.7rem; margin-top:1rem; }}
[data-testid="stSidebar"] [role="radiogroup"] label {{ padding:.38rem .6rem; border-radius:7px; width:100%; }}
[data-testid="stSidebar"] [role="radiogroup"] label:hover {{ background:{C.PANEL}; }}
[data-testid="stVerticalBlockBorderWrapper"] {{ background:{C.PANEL}; border-color:{C.BORDER} !important;
  border-radius:10px; }}
.kpi {{ background:{C.PANEL}; border:1px solid {C.BORDER}; border-left:3px solid {C.RED}; border-radius:10px;
  padding:11px 14px; min-height:88px; }}
.kpi .l {{ color:{C.MUTED}; font-size:.68rem; text-transform:uppercase; letter-spacing:.07em; }}
.kpi .v {{ font-size:1.32rem; font-weight:650; margin-top:2px; line-height:1.25; }}
.kpi .s {{ color:{C.MUTED}; font-size:.72rem; margin-top:1px; }}
.pos {{ color:{C.POS}; }} .neg {{ color:{C.NEG}; }}
.ptitle {{ color:{C.MUTED}; font-size:.74rem; text-transform:uppercase; letter-spacing:.09em; font-weight:600;
  margin:0 0 .35rem 0; }}
.banner {{ background:{C.PANEL}; border:1px solid {C.BORDER}; border-radius:10px; padding:.55rem .9rem;
  font-size:.8rem; color:{C.MUTED}; margin:.3rem 0 .9rem 0; }}
.banner b {{ color:{C.TEXT}; }}
.banner.warn {{ border-left:3px solid #E9A23B; }}
.badge {{ display:inline-block; padding:1px 9px; border-radius:99px; font-size:.7rem; font-weight:600;
  letter-spacing:.04em; margin-right:6px; }}
.b-beg {{ background:#4FB3BF22; color:#4FB3BF; }} .b-int {{ background:#E9A23B22; color:#E9A23B; }}
.b-adv {{ background:#D6455022; color:#D64550; }}
.note {{ color:{C.MUTED}; font-size:.8rem; }}
[data-testid="stTextArea"] textarea {{ font-family:'JetBrains Mono','Fira Code',Consolas,monospace !important;
  font-size:.84rem !important; background:#0F0F1C !important; }}
.stButton>button, .stDownloadButton>button {{ border-radius:8px; border:1px solid {C.BORDER}; font-weight:600; }}
[data-testid="stTabs"] button {{ font-size:.85rem; }}
[data-testid="stDataFrame"] {{ border:1px solid {C.BORDER}; border-radius:8px; }}
hr {{ border-color:{C.BORDER}; }}
</style>
"""


def inject_css():
    st.markdown(CSS, unsafe_allow_html=True)


def kpi(label: str, value: str, sub: str = "", tone: str = "") -> str:
    """HTML for one KPI card. tone: '', 'pos' or 'neg' colours the value."""
    return (f'<div class="kpi"><div class="l">{escape(label)}</div>'
            f'<div class="v {tone}">{value}</div><div class="s">{sub}</div></div>')


def kpi_row(items: list[tuple]):
    cols = st.columns(len(items))
    for col, it in zip(cols, items):
        with col:
            st.markdown(kpi(*it), unsafe_allow_html=True)


def ptitle(text: str):
    st.markdown(f'<div class="ptitle">{escape(text)}</div>', unsafe_allow_html=True)


def banner(html: str, warn: bool = False):
    st.markdown(f'<div class="banner{" warn" if warn else ""}">{html}</div>', unsafe_allow_html=True)


def tone(x) -> str:
    if x is None or pd.isna(x):
        return ""
    return "pos" if x > 0 else "neg" if x < 0 else ""


def data_currency_banner(df: pd.DataFrame):
    """Make it unmistakable that the data is historical, not live."""
    last = df["Date"].max().date()
    today = date.today()
    age = (today - last).days
    banner(f"<b>Historical dataset</b> · last record <b>{last:%d %b %Y}</b> · today is {today:%d %b %Y} "
           f"({age:,} days later). Figures describe the past and are <b>not live market data</b>.", warn=True)


def date_range_slider(df: pd.DataFrame, key: str):
    lo, hi = df["Date"].min().date(), df["Date"].max().date()
    val = st.slider("Date range", min_value=lo, max_value=hi, value=(lo, hi), format="YYYY-MM-DD", key=key)
    return val


def company_color_map(companies):
    return {c: C.color_for(c, i) for i, c in enumerate(companies)}


def csv_bytes(df: pd.DataFrame) -> bytes:
    return df.to_csv(index=False).encode("utf-8")


def stretch_df(df: pd.DataFrame, height=None, **kwargs):
    """st.dataframe with sane defaults (full width, no index)."""
    if height is not None:
        kwargs["height"] = height
    st.dataframe(df, width="stretch", hide_index=True, **kwargs)
