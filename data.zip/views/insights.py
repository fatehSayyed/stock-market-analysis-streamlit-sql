"""Insights & Reports: calculated findings, PowerPoint-reported findings, downloads, PDF."""
import json
from datetime import date

import pandas as pd
import streamlit as st

from utils import analytics as an
from utils import charts as ch
from utils import config as C
from utils import report, ui
from utils import sql_questions as Q


def _source_note(info: dict) -> str:
    if info.get("mode") == "fallback":
        return "Source: combined cleaned dataset (the six original company files were not found in data/)."
    if info.get("mode") == "original_files":
        return f"Source: {len(info['found'])} original company file(s) combined."
    return "Source: uploaded dataset."


def _load_ppt() -> dict:
    try:
        if C.PPT_FINDINGS_FILE.exists():
            return json.loads(C.PPT_FINDINGS_FILE.read_text(encoding="utf-8"))
    except Exception:                               # corrupted file -> start empty
        pass
    return {}


def render(df):
    st.title("Insights & Reports")
    ui.data_currency_banner(df)
    ui.banner("Findings below describe <b>historical</b> data only. They are not investment advice and contain "
              "no buy/sell recommendations.")

    companies = sorted(df[C.COMPANY].unique())
    f1, f2 = st.columns([1.6, 2])
    picked = f1.multiselect("Companies", companies, default=companies, key="f_in_companies")
    with f2:
        start, end = ui.date_range_slider(df, "f_in_range")
    if not picked:
        st.info("Select at least one company.")
        return
    d = an.filter_df(df, picked, start, end)
    if d.empty:
        st.warning("No records in the selected range.")
        return
    ins = an.generate_insights(df, d, start, end)
    stats = ins["stats"]

    # ============================================================ calculated findings
    st.subheader("A · Calculated findings (computed from the data)")
    with st.container(border=True):
        for head, text in ins["bullets"]:
            st.markdown(f"**{head}** — {text}")
        st.caption("Period return = last close / first close in the range − 1. Daily return = % change vs the "
                   "previous trading day. Volatility = std-dev of daily returns.")

    a, b = st.columns(2)
    with a, st.container(border=True):
        ui.ptitle("Best and worst performers · period return (%)")
        st.plotly_chart(ch.bar(stats.sort_values("Period Return (%)", ascending=False), C.COMPANY,
                               "Period Return (%)", 300, signed=True, fmt="+.1f"), width="stretch")
    with b, st.container(border=True):
        ui.ptitle("Volatility comparison · std-dev of daily returns (%)")
        st.plotly_chart(ch.bar(stats.sort_values("Volatility (%)", ascending=False), C.COMPANY,
                               "Volatility (%)", 300), width="stretch")

    tabs = st.tabs(list(ins["tables"].keys()))
    for tab, (name, tbl) in zip(tabs, ins["tables"].items()):
        with tab:
            if tbl is None or len(tbl) == 0:
                st.info("Nothing to report for this selection.")
            else:
                ui.stretch_df(tbl, column_config={
                    C.DATE: st.column_config.DateColumn(format="YYYY-MM-DD"),
                    "Peak Date": st.column_config.DateColumn(format="YYYY-MM-DD"),
                    "Trough Date": st.column_config.DateColumn(format="YYYY-MM-DD"),
                    "Start Date": st.column_config.DateColumn(format="YYYY-MM-DD"),
                    "End Date": st.column_config.DateColumn(format="YYYY-MM-DD")})

    with st.expander("Verification · period returns recomputed independently with SQL"):
        try:
            v = an.verify_period_returns(d)
            ui.stretch_df(v, column_config={"Abs Difference": st.column_config.NumberColumn(format="%.10f")})
            if v["Abs Difference"].max() < 1e-9:
                st.success("Pandas and SQL (DuckDB) agree for every company.")
            else:
                st.error("Mismatch between pandas and SQL results – investigate before reporting.")
        except Exception as exc:
            st.error(f"Verification failed: {exc}")

    # ============================================================ PowerPoint findings
    st.subheader("B · Source-reported findings (PowerPoint)")
    ui.banner("These observations come from the project PowerPoint and are shown <b>as reported</b>. They are "
              "<b>not</b> independently verified by the calculations in section A. The PowerPoint file itself is not "
              "bundled with this app, so enter or paste its per-company observations here (or put them in "
              "<code>data/powerpoint_findings.json</code> as {\"Company\": \"text\"}).", warn=True)
    saved = _load_ppt()
    with st.expander("Enter / edit PowerPoint observations", expanded=not any(saved.values())):
        for comp in companies:
            key = f"f_ppt_{comp}"
            if key not in st.session_state:
                st.session_state[key] = saved.get(comp, "")
            st.text_area(comp, key=key, height=68)
        if st.button("Save to data/powerpoint_findings.json", key="ppt_save"):
            try:
                C.DATA_DIR.mkdir(exist_ok=True)
                payload = {c: st.session_state.get(f"f_ppt_{c}", "") for c in companies}
                C.PPT_FINDINGS_FILE.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")
                st.success("Saved.")
            except Exception as exc:
                st.error(f"Could not save: {exc}")
    ppt = {c: st.session_state.get(f"f_ppt_{c}", "") for c in companies}
    shown = {k: v for k, v in ppt.items() if v.strip()}
    if shown:
        with st.container(border=True):
            for comp, text in shown.items():
                st.markdown(f"**{comp}** — {text}")
            st.caption("Source-reported, unverified.")
    else:
        st.info("No PowerPoint observations entered yet.")

    # ============================================================ data quality
    st.subheader("C · Data quality limitations")
    summary, _ = an.quality_checks(df.drop(columns=[C.MA30, C.MA90], errors="ignore"), date.today())
    flagged = summary[summary["Rows Flagged"] > 0]
    with st.container(border=True):
        if flagged.empty:
            st.success("No rule-based quality flags were raised.")
        else:
            ui.stretch_df(flagged)
        big = d[d[C.RET] < -40]
        if len(big):
            st.warning("Possible unadjusted corporate action: " + "; ".join(
                f"{r[C.COMPANY]} on {r[C.DATE]:%Y-%m-%d} ({r[C.RET]:.1f}%)" for _, r in big.iterrows()) +
                       ". A ~50% one-day fall is consistent with a bonus issue or split (not verified). "
                       "It depresses period return and inflates volatility for that company.")
        st.caption("Missing values are never imputed. Prices are as supplied; no adjustment for splits, bonus "
                   "issues or dividends was applied.")

    # ============================================================ downloads
    st.subheader("D · Downloads")
    c1, c2, c3 = st.columns(3)
    with c1, st.container(border=True):
        ui.ptitle("CSV summaries")
        for name, tbl in {"company_summary": stats, "largest_daily_moves": pd.concat(
                [ins["tables"]["Largest daily gains"].assign(Type="Gain"),
                 ins["tables"]["Largest daily losses"].assign(Type="Loss")]),
                          "data_quality_checks": summary,
                          "max_drawdown": ins["tables"]["Max drawdown detail"]}.items():
            st.download_button(f"{name}.csv", ui.csv_bytes(tbl), f"{name}.csv", "text/csv", key=f"dl_{name}",
                               width="stretch")
    with c2, st.container(border=True):
        ui.ptitle("SQL script")
        company = picked[0]
        script = Q.build_sql_script(company, start, end)
        st.caption(f"All {len(Q.QUESTIONS)} analysis queries as a runnable DuckDB script "
                   f"(parameters: {company}, {start} → {end}).")
        st.download_button("stock_analysis.sql", script.encode("utf-8"), "stock_analysis.sql", "text/plain",
                           key="dl_sql_script", width="stretch")
    with c3, st.container(border=True):
        ui.ptitle("PDF report")
        st.caption("KPIs, charts, methods, calculated findings, PowerPoint findings (separate), data quality.")
        if st.button("Generate PDF report", key="pdf_gen", width="stretch", type="primary"):
            try:
                with st.spinner("Building report..."):
                    st.session_state["pdf_bytes"] = report.build_pdf(
                        df, d, start, end, ppt, summary, _source_note(st.session_state.get("source_info", {})))
            except Exception as exc:
                st.session_state.pop("pdf_bytes", None)
                st.error(f"Report generation failed: {exc}")
        if st.session_state.get("pdf_bytes"):
            st.download_button("Download PDF", st.session_state["pdf_bytes"], "stock_market_report.pdf",
                               "application/pdf", key="dl_pdf", width="stretch")
            st.caption("PDF reflects the selection at the time you pressed Generate.")
