"""SQL Playground: question bank + editable, read-only DuckDB execution."""
import streamlit as st

from utils import config as C
from utils import sql_engine as SE
from utils import sql_questions as Q
from utils import ui

BADGE = {"Beginner": "b-beg", "Intermediate": "b-int", "Advanced": "b-adv"}


def _defaults(df):
    return sorted(df[C.COMPANY].unique())[0], df[C.DATE].min().date(), df[C.DATE].max().date()


def _question_from_state():
    label_map = {Q.label(q): q for q in Q.QUESTIONS}
    return label_map.get(st.session_state.get("sql_q")), label_map


def _load_sql():
    """Callback: put the selected question's SQL (with parameters filled in) into the editor."""
    q, _ = _question_from_state()
    if q is None:
        return
    company, lo, hi = _defaults(st.session_state["df"])
    rng = st.session_state.get("sql_range", (lo, hi))
    st.session_state["sql_editor"] = Q.render_sql(q, st.session_state.get("sql_company", company), rng[0], rng[1])


def _level_changed():
    st.session_state.pop("sql_q", None)             # first question of the new level is selected
    _load_sql_after_level()


def _load_sql_after_level():
    lvl = st.session_state.get("sql_level", "All")
    qs = [q for q in Q.QUESTIONS if lvl == "All" or q["level"] == lvl]
    st.session_state["sql_q"] = Q.label(qs[0])
    _load_sql()


def render(df):
    st.title("SQL Playground")
    ui.data_currency_banner(df)
    ui.banner("Queries run for real against the loaded dataset, registered as the table <b>stock_data</b> "
              "(DuckDB, in-memory, read-only). Pick a question, edit the SQL, and press <b>Run query</b>.")

    # ------------------------------------------------------------------ question selector
    if "sql_level" not in st.session_state:
        st.session_state["sql_level"] = "All"
    if "sql_q" not in st.session_state:
        st.session_state["sql_q"] = Q.label(Q.QUESTIONS[0])
    if "sql_editor" not in st.session_state:
        _load_sql()

    left, right = st.columns([1.15, 1])
    with left, st.container(border=True):
        ui.ptitle(f"Question bank · {len(Q.QUESTIONS)} questions")
        st.radio("Difficulty", ["All"] + Q.LEVELS, horizontal=True, key="sql_level", on_change=_level_changed)
        lvl = st.session_state["sql_level"]
        options = [Q.label(q) for q in Q.QUESTIONS if lvl == "All" or q["level"] == lvl]
        if st.session_state["sql_q"] not in options:
            st.session_state["sql_q"] = options[0]
        st.selectbox("Question (type to search)", options, key="sql_q", on_change=_load_sql)
        q, _ = _question_from_state()

        st.markdown(f'<span class="badge {BADGE[q["level"]]}">{q["level"].upper()}</span> '
                    f'<b>Q{q["id"]}. {q["title"]}</b>', unsafe_allow_html=True)
        st.write(q["description"])
        st.caption(f"Concept: {q['concept']}")

        company, lo, hi = _defaults(df)
        if "company" in q["params"]:
            st.selectbox("Company parameter", sorted(df[C.COMPANY].unique()), key="sql_company",
                         on_change=_load_sql)
        if "date_range" in q["params"]:
            st.slider("Date range parameter", min_value=lo, max_value=hi, value=(lo, hi), format="YYYY-MM-DD",
                      key="sql_range", on_change=_load_sql)
        with st.expander("Solution explanation"):
            st.write(q["explanation"])

    with right, st.container(border=True):
        ui.ptitle("stock_data schema")
        if "sql_schema" not in st.session_state:
            st.session_state["sql_schema"] = SE.get_schema(df)
        ui.stretch_df(st.session_state["sql_schema"], height=300)
        with st.expander("Sample rows (first 5)"):
            ui.stretch_df(SE.to_sql_frame(df).head(5))

    # ------------------------------------------------------------------ editor
    with st.container(border=True):
        ui.ptitle("SQL editor")
        st.text_area("SQL query", key="sql_editor", height=290, label_visibility="collapsed")
        b1, b2, b3 = st.columns([1, 1, 4])
        run = b1.button("▶ Run query", type="primary", key="sql_run", width="stretch")
        b2.button("↺ Reset", key="sql_reset", on_click=_load_sql, width="stretch",
                  help="Restore the original query for the selected question")
        b3.caption(f"Read-only · one statement · max {SE.MAX_ROWS:,} rows · {SE.TIMEOUT_SECONDS}s timeout. "
                   "DROP, DELETE, UPDATE, INSERT, ALTER and similar commands are rejected.")

        if run:
            with st.spinner("Running..."):
                st.session_state["sql_result"] = SE.run_query(df, st.session_state["sql_editor"])

        res = st.session_state.get("sql_result")
        if res is not None:
            st.divider()
            ui.ptitle("Results")
            if res.error:
                st.error(res.error)
            elif res.df is None or res.df.empty:
                st.info("The query ran successfully but returned no rows.")
            else:
                msg = f"{len(res.df):,} row(s) × {res.df.shape[1]} column(s) · {res.elapsed_ms:,.0f} ms"
                st.caption(msg)
                if res.truncated:
                    st.warning(f"Result truncated to the first {SE.MAX_ROWS:,} rows. Add a WHERE clause or LIMIT.")
                ui.stretch_df(res.df, height=min(520, 38 + 35 * len(res.df)))
                st.download_button("Download results (CSV)", ui.csv_bytes(res.df), "query_results.csv",
                                   "text/csv", key="dl_sql")
