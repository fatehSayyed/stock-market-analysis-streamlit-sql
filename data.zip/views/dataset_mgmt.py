"""Dataset Management: upload, column mapping, quality summary, combined download, reload."""
import pandas as pd
import streamlit as st

from utils import analytics as an
from utils import config as C
from utils import data_loader as dl
from utils import state, ui


def _combine(frames: list[pd.DataFrame], mode: str, current_raw: pd.DataFrame) -> pd.DataFrame:
    parts = ([current_raw] if mode.startswith("Append") and len(current_raw) else []) + frames
    return pd.concat(parts, ignore_index=True)


def render(df):
    st.title("Dataset Management")
    info = st.session_state.get("source_info", {})
    if st.session_state.get("load_error"):
        st.error(st.session_state["load_error"])

    # ------------------------------------------------------------- current dataset
    with st.container(border=True):
        ui.ptitle("Current dataset")
        if info.get("mode") == "fallback":
            st.warning(f"Using the combined file **{C.FALLBACK_FILE}** because the six original company CSVs were not "
                       f"found in the data/ folder. Missing: {', '.join(info.get('missing', []))}.")
        elif info.get("mode") == "original_files":
            st.success(f"Loaded {len(info['found'])} of {len(C.COMPANY_FILES)} original files from data/.")
            if info.get("missing"):
                st.warning("Missing files: " + ", ".join(info["missing"]))
        elif info.get("mode") == "custom":
            st.info("Using an uploaded / modified dataset (the bundled files are unchanged on disk).")
        if len(df):
            ui.kpi_row([("Rows", f"{len(df):,}", ""), ("Companies", f"{df[C.COMPANY].nunique()}", ""),
                        ("From", f"{df[C.DATE].min():%Y-%m-%d}", ""), ("To", f"{df[C.DATE].max():%Y-%m-%d}", "")])
        a, b = st.columns([1, 1])
        if a.button("↻ Reload the six original files", key="reload", width="stretch"):
            state.init_state(force=True)
            st.rerun()
        if len(df):
            export = df.drop(columns=[C.MA30, C.MA90], errors="ignore")
            b.download_button("⬇ Download combined dataset (CSV)", ui.csv_bytes(export), "combined_stock_data.csv",
                              "text/csv", key="dl_combined", width="stretch")

    # ------------------------------------------------------------- upload
    st.subheader("Upload CSV files")
    st.caption(f"Expected columns: {', '.join(c for c in C.ALL_COLS if c not in (C.RET,))}. Headers are matched "
               "flexibly (e.g. 'Close', 'Open Price', 'Total Turnover (Rs.)'). `Daily Return (%)` is always "
               "recalculated.")
    files = st.file_uploader("Choose one or more CSV files", type="csv", accept_multiple_files=True, key="uploader")
    if files:
        prepared, blocking = [], False
        for i, f in enumerate(files):
            with st.container(border=True):
                ui.ptitle(f"File · {f.name}")
                try:
                    raw = dl.read_csv_any(f)
                except Exception as exc:
                    st.error(f"Could not read {f.name}: {exc}")
                    blocking = True
                    continue
                norm, mapping = dl.normalize_columns(raw)
                norm = norm.drop(columns=[c for c in norm.columns if str(c).startswith("Unnamed")])
                st.caption(f"{len(raw):,} rows · {raw.shape[1]} columns · {len(mapping)} header(s) recognised automatically")

                has_company = C.COMPANY in norm.columns
                default_name = f.name.rsplit(".", 1)[0]
                company = st.text_input("Company name for this file", default_name, key=f"f_up_name_{i}",
                                        disabled=has_company,
                                        help="Ignored when the file has its own Company column." if has_company else None)
                if not has_company:
                    norm[C.COMPANY] = company.strip() or default_name

                # column mapping for unmapped required/expected columns
                miss = dl.missing_expected_columns(norm)
                unmapped_src = [c for c in norm.columns if c not in C.ALL_COLS]
                if miss["required"] or miss["optional"]:
                    if miss["required"]:
                        st.error("Required column(s) missing: " + ", ".join(miss["required"]) +
                                 ". Map them below or the file cannot be used.")
                    if miss["optional"]:
                        st.warning("Optional column(s) not found (they will be stored as empty, not estimated): "
                                   + ", ".join(miss["optional"]))
                    with st.expander("Column mapping", expanded=bool(miss["required"])):
                        for tgt in miss["required"] + miss["optional"]:
                            choice = st.selectbox(f"Use for '{tgt}'", ["(none)"] + unmapped_src, key=f"f_up_map_{i}_{tgt}")
                            if choice != "(none)":
                                norm[tgt] = norm[choice]
                    miss = dl.missing_expected_columns(norm)
                    if miss["required"]:
                        blocking = True
                st.dataframe(norm.head(8), width="stretch", hide_index=True)
                prepared.append(norm)

        if prepared:
            mode = st.radio("How should these files be used?",
                            ["Append to the current dataset", "Replace the current dataset"], horizontal=True,
                            key="f_up_mode")
            if st.button("Process and apply", type="primary", disabled=blocking, key="apply_upload"):
                try:
                    combined = _combine(prepared, mode, st.session_state.get("raw_df", pd.DataFrame()))
                    res = dl.clean_data(combined)
                    state.set_dataset(combined, res.df, res.log, {"mode": "custom", "found": [f.name for f in files],
                                                                  "missing": []})
                    st.success(f"Dataset updated: {len(res.df):,} rows, {res.df[C.COMPANY].nunique()} companies.")
                    st.rerun()
                except Exception as exc:
                    st.error(f"Could not process the files: {exc}")
            if blocking:
                st.caption("Resolve the errors above to enable processing.")

    # ------------------------------------------------------------- quality + log
    if len(df):
        base = df.drop(columns=[C.MA30, C.MA90], errors="ignore")
        st.subheader("Preview and data quality summary")
        t1, t2, t3 = st.tabs(["Preview", "Quality summary", "Cleaning log"])
        with t1:
            ui.stretch_df(base.head(50), height=360,
                          column_config={C.DATE: st.column_config.DateColumn(format="YYYY-MM-DD")})
        with t2:
            ui.stretch_df(an.column_quality_summary(base))
            ui.stretch_df(an.coverage_table(base))
        with t3:
            log = pd.DataFrame(st.session_state.get("clean_log", []))
            if len(log):
                ui.stretch_df(log.rename(columns={"step": "Step", "detail": "Detail", "rows": "Rows affected"}))
            st.caption("The original files on disk are never modified; analysis runs on this cleaned copy.")
