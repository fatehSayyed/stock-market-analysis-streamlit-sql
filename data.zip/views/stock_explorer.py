"""Stock Explorer: multi-company exploration of prices, returns, volume, spreads, delivery."""
import pandas as pd
import streamlit as st

from utils import analytics as an
from utils import charts as ch
from utils import config as C
from utils import ui


def render(df):
    st.title("Stock Explorer")
    ui.data_currency_banner(df)

    companies = sorted(df[C.COMPANY].unique())
    f1, f2 = st.columns([1.2, 2])
    picked = f1.multiselect("Companies", companies, default=companies[:1], key="f_ex_companies")
    with f2:
        start, end = ui.date_range_slider(df, "f_ex_range")
    if not picked:
        st.info("Select at least one company.")
        return
    d = an.filter_df(df, picked, start, end)
    if d.empty:
        st.warning("No records in the selected range.")
        return
    if len(picked) > 1:
        ui.banner("Raw share prices are <b>not directly comparable</b> between companies (different price "
                  "levels). Use returns or the normalised index on the Company Comparison page to compare performance.")

    tabs = st.tabs(["Prices", "Close & moving averages", "Returns", "Volume & turnover",
                    "Spreads", "Delivery", "Data table"])

    # ---- prices (OHLC / WAP)
    with tabs[0]:
        with st.container(border=True):
            if len(picked) == 1:
                ui.ptitle(f"{picked[0]} · OHLC candlesticks with WAP")
                st.plotly_chart(ch.candlestick(d), width="stretch")
            else:
                field = st.selectbox("Price field", [C.OPEN, C.HIGH, C.LOW, C.CLOSE, C.WAP], index=3, key="f_ex_field")
                ui.ptitle(f"{field} by company")
                st.plotly_chart(ch.multi_line(d, field, "Price (Rs.)"), width="stretch")
                st.caption("Select a single company to see the OHLC candlestick view.")

    # ---- close & MAs
    with tabs[1]:
        m1, m2, _ = st.columns([1, 1, 4])
        s30 = m1.checkbox("30-day MA", True, key="f_ex_ma30")
        s90 = m2.checkbox("90-day MA", True, key="f_ex_ma90")
        for comp in picked:
            with st.container(border=True):
                ui.ptitle(f"{comp} · close with moving averages")
                st.plotly_chart(ch.price_chart(d[d[C.COMPANY] == comp], s30, s90, 320), width="stretch")
        st.caption("Moving averages use the full history before the selected start date and are shown only "
                   "once a complete 30 / 90-observation window exists.")

    # ---- returns
    with tabs[2]:
        with st.container(border=True):
            ui.ptitle("Daily return (%) · per company, vs previous trading day")
            st.plotly_chart(ch.multi_line(d, C.RET, "Daily return (%)", hline=0), width="stretch")
        with st.container(border=True):
            ui.ptitle("Distribution of daily returns")
            st.plotly_chart(ch.histogram(d.dropna(subset=[C.RET]), C.RET, xlabel="Daily return (%)"),
                            width="stretch")
        s = an.company_stats(d)[[C.COMPANY, "Avg Daily Return (%)", "Volatility (%)", "Positive Days",
                                 "Negative Days"]]
        ui.stretch_df(s)

    # ---- volume & turnover
    with tabs[3]:
        a, b = st.columns(2)
        with a, st.container(border=True):
            ui.ptitle("Shares traded")
            st.plotly_chart(ch.multi_bar_ts(d, C.SHARES, "Shares"), width="stretch")
        with b, st.container(border=True):
            ui.ptitle("Turnover (Rs. crore)")
            t = d.assign(**{"Turnover (Rs. Cr)": d[C.TURNOVER] / 1e7})
            st.plotly_chart(ch.multi_bar_ts(t, "Turnover (Rs. Cr)", "Rs. crore"), width="stretch")
        with st.container(border=True):
            ui.ptitle("Number of trades")
            st.plotly_chart(ch.multi_line(d, C.TRADES, "Trades"), width="stretch")

    # ---- spreads
    with tabs[4]:
        a, b = st.columns(2)
        with a, st.container(border=True):
            ui.ptitle("Spread High - Low (Rs.) · daily range")
            st.plotly_chart(ch.multi_line(d, C.SPREAD_HL, "Rs."), width="stretch")
        with b, st.container(border=True):
            ui.ptitle("Spread Close - Open (Rs.) · intraday move")
            st.plotly_chart(ch.multi_line(d, C.SPREAD_CO, "Rs.", hline=0), width="stretch")

    # ---- delivery
    with tabs[5]:
        dv = d.dropna(subset=[C.DELIV])
        miss = int(d[C.DELIV].isna().sum())
        if miss:
            st.caption(f"{miss} record(s) have no delivery data and are left blank (not estimated).")
        a, b = st.columns(2)
        with a, st.container(border=True):
            ui.ptitle("Delivery % of traded quantity")
            st.plotly_chart(ch.multi_line(dv, C.DELIV_PCT, "% delivered"), width="stretch")
        with b, st.container(border=True):
            ui.ptitle("Deliverable quantity")
            st.plotly_chart(ch.multi_line(dv, C.DELIV, "Shares"), width="stretch")
        ui.stretch_df(an.activity_table(d), column_config={
            "Avg Shares / Day": st.column_config.NumberColumn(format="%,.0f"),
            "Avg Trades / Day": st.column_config.NumberColumn(format="%,.0f"),
            "Avg Turnover / Day (Rs.)": st.column_config.NumberColumn(format="%,.0f"),
            "Avg Delivery (%)": st.column_config.NumberColumn(format="%.2f"),
            "Avg Deliverable Qty": st.column_config.NumberColumn(format="%,.0f")})

    # ---- searchable table
    with tabs[6]:
        q1, q2 = st.columns([1, 2])
        query = q1.text_input("Search rows", placeholder="e.g. 2016-03, TCS, 1850", key="f_ex_search")
        cols = [c for c in d.columns]
        show_cols = q2.multiselect("Columns", cols, default=[c for c in cols if c not in (C.MA30, C.MA90)],
                                   key="f_ex_cols")
        view = d[show_cols] if show_cols else d
        if query:
            hay = view.astype(str).agg(" ".join, axis=1)
            view = view[hay.str.contains(query, case=False, regex=False)]
        st.caption(f"{len(view):,} of {len(d):,} rows · click a column header to sort")
        st.dataframe(view.sort_values([C.COMPANY, C.DATE]) if {C.COMPANY, C.DATE} <= set(view.columns) else view,
                     width="stretch", hide_index=True, height=420,
                     column_config={C.DATE: st.column_config.DateColumn(format="YYYY-MM-DD")})
        st.download_button("Download filtered data (CSV)", ui.csv_bytes(view), "filtered_stock_data.csv",
                           "text/csv", key="dl_explorer")
