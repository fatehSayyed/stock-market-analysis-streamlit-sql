"""Market Overview: KPI cards, price/volume charts, company comparison panels."""
import streamlit as st

from utils import analytics as an
from utils import charts as ch
from utils import config as C
from utils import ui


def render(df):
    st.title("Market Overview")
    ui.data_currency_banner(df)

    companies = sorted(df[C.COMPANY].unique())
    f1, f2 = st.columns([1, 2])
    company = f1.selectbox("Company", companies, key="f_ov_company")
    with f2:
        start, end = ui.date_range_slider(df, "f_ov_range")

    in_range = an.filter_df(df, None, start, end)            # all companies, selected dates
    sel = an.filter_df(df, [company], start, end)            # one company, selected dates
    if sel.empty:
        st.warning("No records for this company in the selected date range.")
        return
    k = an.overview_kpis(df, sel)

    # ------------------------------------------------------------- KPI cards
    ui.kpi_row([
        ("Total records", f"{k['total_records']:,}", f"{k['selected_records']:,} in selection"),
        ("Companies", f"{k['companies']}", "in dataset"),
        ("Latest market date", f"{k['latest_date']:%d %b %Y}", "last historical record, not today"),
        (f"Latest close · {company}", f"Rs. {k['latest_close']:,.2f}", f"on {k['latest_close_date']:%d %b %Y}"),
    ])
    st.write("")
    ui.kpi_row([
        ("Avg daily return", an.fmt_pct(k["avg_return"], 3), "selected company & range", ui.tone(k["avg_return"])),
        ("Total turnover", an.fmt_rs(k["turnover"]), "selected company & range"),
        ("High / low close", f"{k['high_close']:,.1f} / {k['low_close']:,.1f}",
         f"{k['high_date']:%d %b %y} / {k['low_date']:%d %b %y}"),
        ("Positive vs negative days", f'<span class="pos">{k["pos_days"]}</span> / '
                                      f'<span class="neg">{k["neg_days"]}</span>',
         f"{k['flat_days']} unchanged"),
    ])
    st.write("")

    # ------------------------------------------------------------- tables left, charts right
    stats = an.company_stats(in_range)
    left, right = st.columns([1, 1.75])
    with left:
        with st.container(border=True):
            ui.ptitle("Company performance · selected range")
            show = stats[[C.COMPANY, "Period Return (%)", "Avg Daily Return (%)", "Volatility (%)",
                          "Total Turnover (Rs.)"]].sort_values("Period Return (%)", ascending=False).copy()
            show["Total Turnover (Rs.)"] = show["Total Turnover (Rs.)"] / 1e7
            show = show.rename(columns={"Total Turnover (Rs.)": "Turnover (Rs. Cr)"})
            st.dataframe(show, width="stretch", hide_index=True, column_config={
                "Period Return (%)": st.column_config.NumberColumn(format="%+.2f"),
                "Avg Daily Return (%)": st.column_config.NumberColumn(format="%+.3f"),
                "Volatility (%)": st.column_config.NumberColumn(format="%.2f"),
                "Turnover (Rs. Cr)": st.column_config.NumberColumn(format="%,.0f")})
        with st.container(border=True):
            ui.ptitle("Top gainers & losers")
            t1, t2 = st.tabs(["Companies (period return)", f"{company} · best / worst days"])
            with t1:
                ranked = stats[[C.COMPANY, "Period Return (%)"]].sort_values("Period Return (%)", ascending=False)
                n = min(3, len(ranked))
                st.caption("Top gainers")
                st.dataframe(ranked.head(n), width="stretch", hide_index=True, column_config={
                    "Period Return (%)": st.column_config.NumberColumn(format="%+.2f")})
                st.caption("Top losers")
                st.dataframe(ranked.tail(n).iloc[::-1], width="stretch", hide_index=True, column_config={
                    "Period Return (%)": st.column_config.NumberColumn(format="%+.2f")})
            with t2:
                cfg = {C.RET: st.column_config.NumberColumn("Return (%)", format="%+.2f"),
                       C.DATE: st.column_config.DateColumn("Date", format="YYYY-MM-DD")}
                st.caption("Best 5 days")
                st.dataframe(an.top_daily_moves(sel, 5, False, False), width="stretch", hide_index=True,
                             column_config=cfg)
                st.caption("Worst 5 days")
                st.dataframe(an.top_daily_moves(sel, 5, True, False), width="stretch", hide_index=True,
                             column_config=cfg)
    with right:
        with st.container(border=True):
            ui.ptitle(f"{company} · closing price with 30 / 90-day moving averages")
            m1, m2, _ = st.columns([1, 1, 4])
            s30 = m1.checkbox("30-day MA", True, key="f_ov_ma30")
            s90 = m2.checkbox("90-day MA", True, key="f_ov_ma90")
            st.plotly_chart(ch.price_chart(sel, s30, s90, 330), width="stretch")
        with st.container(border=True):
            ui.ptitle(f"{company} · trading volume (shares)")
            st.plotly_chart(ch.volume_chart(sel, 215), width="stretch")

    # ------------------------------------------------------------- comparative panels
    c1, c2, c3 = st.columns(3)
    with c1, st.container(border=True):
        ui.ptitle(f"{company} · daily returns (%)")
        st.plotly_chart(ch.returns_chart(sel, 260), width="stretch")
    with c2, st.container(border=True):
        ui.ptitle(f"{company} · daily turnover (Rs. crore)")
        st.plotly_chart(ch.turnover_chart(sel, 260), width="stretch")
    with c3, st.container(border=True):
        ui.ptitle("All companies · period return (%)")
        st.plotly_chart(ch.bar(stats.sort_values("Period Return (%)", ascending=False), C.COMPANY,
                               "Period Return (%)", 260, signed=True, fmt="+.1f"), width="stretch")

    with st.container(border=True):
        ui.ptitle(f"{company} · most recent records in selection")
        cols = [C.DATE, C.OPEN, C.HIGH, C.LOW, C.CLOSE, C.SHARES, C.TURNOVER, C.RET]
        recent = sel.sort_values(C.DATE, ascending=False)[cols].head(15)
        st.dataframe(recent, width="stretch", hide_index=True, column_config={
            C.DATE: st.column_config.DateColumn(format="YYYY-MM-DD"),
            C.RET: st.column_config.NumberColumn("Return (%)", format="%+.2f"),
            C.TURNOVER: st.column_config.NumberColumn(format="%,.0f"),
            C.SHARES: st.column_config.NumberColumn(format="%,d")})
