"""Company Comparison: consistent definitions across all selected companies."""
import streamlit as st

from utils import analytics as an
from utils import charts as ch
from utils import config as C
from utils import ui


def render(df):
    st.title("Company Comparison")
    ui.data_currency_banner(df)
    companies = sorted(df[C.COMPANY].unique())
    f1, f2 = st.columns([1.6, 2])
    picked = f1.multiselect("Companies", companies, default=companies, key="f_cmp_companies")
    with f2:
        start, end = ui.date_range_slider(df, "f_cmp_range")
    if len(picked) < 2:
        st.info("Select at least two companies to compare.")
        return
    d = an.filter_df(df, picked, start, end)
    if d.empty:
        st.warning("No records in the selected range.")
        return
    ui.banner("<b>Why not compare raw prices?</b> Share prices depend on each company's share count and history, so a "
              "Rs. 3,000 stock is not 'bigger' than a Rs. 300 stock. Fair comparisons use <b>percentage returns</b>, "
              "a <b>normalised index (start = 100)</b> and risk measures. All companies use identical definitions.")

    s = an.company_stats(d)
    best, worst = s.loc[s["Period Return (%)"].idxmax()], s.loc[s["Period Return (%)"].idxmin()]
    calm = s.loc[s["Volatility (%)"].idxmin()]
    ui.kpi_row([
        ("Best period return", f"{best['Period Return (%)']:+.2f}%", best[C.COMPANY], "pos"),
        ("Worst period return", f"{worst['Period Return (%)']:+.2f}%", worst[C.COMPANY], ui.tone(worst["Period Return (%)"])),
        ("Lowest volatility", f"{calm['Volatility (%)']:.2f}%", calm[C.COMPANY]),
        ("Highest turnover", an.fmt_rs(s["Total Turnover (Rs.)"].max()),
         s.loc[s["Total Turnover (Rs.)"].idxmax(), C.COMPANY]),
    ])
    st.write("")
    tabs = st.tabs(["Performance", "Risk", "Trading activity", "Correlation", "Rankings"])

    with tabs[0]:
        with st.container(border=True):
            ui.ptitle("Normalised performance · start of period = 100")
            st.plotly_chart(ch.multi_line(an.normalized_performance(d), "Index (base=100)", "Index", 400, hline=100),
                            width="stretch")
        a, b = st.columns(2)
        with a, st.container(border=True):
            ui.ptitle("Period return (%) · first to last close in range")
            st.plotly_chart(ch.bar(s.sort_values("Period Return (%)", ascending=False), C.COMPANY,
                                   "Period Return (%)", 300, signed=True, fmt="+.1f"), width="stretch")
        with b, st.container(border=True):
            ui.ptitle("Average daily return (%)")
            st.plotly_chart(ch.bar(s.sort_values("Avg Daily Return (%)", ascending=False), C.COMPANY,
                                   "Avg Daily Return (%)", 300, signed=True, fmt="+.3f"), width="stretch")
        with st.container(border=True):
            ui.ptitle("Closing price trends · raw prices, shown for reference only")
            log = st.checkbox("Logarithmic price axis", True, key="f_cmp_log")
            fig = ch.multi_line(d, C.CLOSE, "Close (Rs.)", 340)
            if log:
                fig.update_yaxes(type="log")
            st.plotly_chart(fig, width="stretch")

    with tabs[1]:
        a, b = st.columns(2)
        with a, st.container(border=True):
            ui.ptitle("Return volatility · std-dev of daily returns (%)")
            st.plotly_chart(ch.bar(s.sort_values("Volatility (%)", ascending=False), C.COMPANY,
                                   "Volatility (%)", 300), width="stretch")
        with b, st.container(border=True):
            ui.ptitle("Maximum drawdown (%)")
            st.plotly_chart(ch.bar(s.sort_values("Max Drawdown (%)"), C.COMPANY, "Max Drawdown (%)", 300,
                                   signed=True, fmt=".1f"), width="stretch")
        with st.container(border=True):
            ui.ptitle("Drawdown from running peak close")
            st.plotly_chart(ch.drawdown_chart(an.drawdown_series(d)), width="stretch")
        with st.container(border=True):
            ui.ptitle("Maximum drawdown detail")
            ui.stretch_df(an.max_drawdown_table(d), column_config={
                "Peak Date": st.column_config.DateColumn(format="YYYY-MM-DD"),
                "Trough Date": st.column_config.DateColumn(format="YYYY-MM-DD"),
                "Max Drawdown (%)": st.column_config.NumberColumn(format="%.2f")})
        st.caption("Drawdown = Close / highest Close so far in the selected window - 1. Volatility includes any "
                   "one-day corporate-action jumps (e.g. -50% bonus-style moves), which can distort risk figures.")

    with tabs[2]:
        a, b = st.columns(2)
        with a, st.container(border=True):
            ui.ptitle("Average daily turnover (Rs. crore)")
            x = s.assign(v=s["Avg Daily Turnover (Rs.)"] / 1e7).sort_values("v", ascending=False)
            st.plotly_chart(ch.bar(x, C.COMPANY, "v", 300, ylabel="Rs. crore", fmt=",.1f"), width="stretch")
        with b, st.container(border=True):
            ui.ptitle("Total turnover (Rs. crore)")
            x = s.assign(v=s["Total Turnover (Rs.)"] / 1e7).sort_values("v", ascending=False)
            st.plotly_chart(ch.bar(x, C.COMPANY, "v", 300, ylabel="Rs. crore", fmt=",.0f"), width="stretch")
        a, b = st.columns(2)
        with a, st.container(border=True):
            ui.ptitle("Average shares traded per day")
            st.plotly_chart(ch.bar(s.sort_values("Avg Daily Shares", ascending=False), C.COMPANY,
                                   "Avg Daily Shares", 300, fmt=",.0f"), width="stretch")
        with b, st.container(border=True):
            ui.ptitle("Average trades per day")
            st.plotly_chart(ch.bar(s.sort_values("Avg Daily Trades", ascending=False), C.COMPANY,
                                   "Avg Daily Trades", 300, fmt=",.0f"), width="stretch")
        with st.container(border=True):
            ui.ptitle("Rolling turnover (Rs. crore, 30-day average)")
            t = d.copy()
            t["Turnover 30d avg (Rs. Cr)"] = (t.groupby(C.COMPANY)[C.TURNOVER]
                                              .transform(lambda v: v.rolling(30, min_periods=30).mean()) / 1e7)
            st.plotly_chart(ch.multi_line(t.dropna(subset=["Turnover 30d avg (Rs. Cr)"]),
                                          "Turnover 30d avg (Rs. Cr)", "Rs. crore"), width="stretch")

    with tabs[3]:
        a, b = st.columns(2)
        with a, st.container(border=True):
            ui.ptitle("Correlation of daily returns")
            st.plotly_chart(ch.heatmap(an.return_correlation(d), 420), width="stretch")
        with b, st.container(border=True):
            ui.ptitle("Correlation of closing prices (levels)")
            st.plotly_chart(ch.heatmap(d.pivot_table(index=C.DATE, columns=C.COMPANY, values=C.CLOSE).corr(), 420),
                            width="stretch")
        st.caption("Return correlations measure whether stocks move together day to day. Price-level correlations "
                   "mostly reflect shared trends over time and can be misleading (spurious correlation).")

    with tabs[4]:
        r = s[[C.COMPANY, "Period Return (%)", "Avg Daily Return (%)", "Volatility (%)", "Max Drawdown (%)",
               "Total Turnover (Rs.)", "Avg Daily Trades", "Avg Delivery (%)"]].copy()
        r["Return rank"] = r["Period Return (%)"].rank(ascending=False, method="min").astype(int)
        r["Volatility rank (1 = lowest)"] = r["Volatility (%)"].rank(method="min").astype(int)
        r["Drawdown rank (1 = shallowest)"] = r["Max Drawdown (%)"].rank(ascending=False, method="min").astype(int)
        r["Turnover rank"] = r["Total Turnover (Rs.)"].rank(ascending=False, method="min").astype(int)
        r["Return / volatility"] = r["Period Return (%)"] / r["Volatility (%)"]
        r = r.sort_values("Return rank")
        with st.container(border=True):
            ui.ptitle("Company-wise ranking table")
            st.dataframe(r, width="stretch", hide_index=True, column_config={
                "Period Return (%)": st.column_config.NumberColumn(format="%+.2f"),
                "Avg Daily Return (%)": st.column_config.NumberColumn(format="%+.3f"),
                "Volatility (%)": st.column_config.NumberColumn(format="%.2f"),
                "Max Drawdown (%)": st.column_config.NumberColumn(format="%.1f"),
                "Total Turnover (Rs.)": st.column_config.NumberColumn(format="%,.0f"),
                "Avg Daily Trades": st.column_config.NumberColumn(format="%,.0f"),
                "Avg Delivery (%)": st.column_config.NumberColumn(format="%.1f"),
                "Return / volatility": st.column_config.NumberColumn(format="%.2f")})
            st.caption("'Return / volatility' is a simple descriptive ratio of past data, not a recommendation.")
        st.download_button("Download comparison table (CSV)", ui.csv_bytes(s), "company_comparison.csv", "text/csv",
                           key="dl_cmp")
