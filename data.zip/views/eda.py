"""Exploratory Data Analysis: overview, data quality, statistical analysis."""
from datetime import date

import numpy as np
import pandas as pd
import streamlit as st

from utils import analytics as an
from utils import charts as ch
from utils import config as C
from utils import ui

NUM_FOR_EDA = [C.OPEN, C.HIGH, C.LOW, C.CLOSE, C.WAP, C.SHARES, C.TRADES, C.TURNOVER, C.DELIV,
               C.DELIV_PCT, C.SPREAD_HL, C.SPREAD_CO, C.RET]


def render(df):
    st.title("Exploratory Data Analysis")
    base = df.drop(columns=[C.MA30, C.MA90], errors="ignore")      # analysis columns only
    t1, t2, t3 = st.tabs(["Dataset overview", "Data quality", "Statistical analysis"])

    # =============================================================== overview
    with t1:
        ui.kpi_row([("Shape", f"{base.shape[0]:,} × {base.shape[1]}", "rows × columns"),
                    ("Companies", f"{base[C.COMPANY].nunique()}", ", ".join(sorted(base[C.COMPANY].unique()))[:48]),
                    ("Date coverage", f"{base[C.DATE].min():%Y-%m-%d}", f"to {base[C.DATE].max():%Y-%m-%d}"),
                    ("Duplicates", f"{an.duplicate_report(base)['exact']}", "exact duplicate rows")])
        st.write("")
        a, b = st.columns(2)
        with a, st.container(border=True):
            ui.ptitle("head()")
            n = st.slider("Rows", 3, 30, 5, key="f_eda_head")
            ui.stretch_df(base.head(n))
        with b, st.container(border=True):
            ui.ptitle("tail()")
            ui.stretch_df(base.tail(n))
        a, b = st.columns(2)
        with a, st.container(border=True):
            ui.ptitle("info()")
            st.code(an.info_text(base), language="text")
        with b, st.container(border=True):
            ui.ptitle("Column data types")
            ui.stretch_df(pd.DataFrame({"Column": base.columns, "dtype": base.dtypes.astype(str).values}))
        with st.container(border=True):
            ui.ptitle("describe() · numeric summary")
            ui.stretch_df(base.describe().T.reset_index().rename(columns={"index": "Column"}))
        a, b = st.columns(2)
        with a, st.container(border=True):
            ui.ptitle("Companies and date coverage")
            ui.stretch_df(an.coverage_table(base))
        with b, st.container(border=True):
            ui.ptitle("Duplicate checks")
            dup = an.duplicate_report(base)
            st.write(f"Exact duplicate rows: **{dup['exact']}**")
            st.write(f"Duplicate Company + Date keys: **{dup['company_date']}**")
            st.caption("Exact duplicates were removed while cleaning (see the log on Dataset Management); "
                       "key duplicates are only reported.")
        a, b = st.columns(2)
        with a, st.container(border=True):
            ui.ptitle("Missing values by column")
            ui.stretch_df(an.missing_by_column(base))
        with b, st.container(border=True):
            ui.ptitle("Missing values by company")
            mc = an.missing_by_company(base)
            if mc.empty:
                st.success("No missing values.")
            else:
                st.dataframe(mc.reset_index(), width="stretch", hide_index=True)

    # =============================================================== data quality
    with t2:
        with st.container(border=True):
            ui.ptitle("Missing-value map · % of rows missing per company and column")
            miss = base.drop(columns=[C.COMPANY]).isna().groupby(base[C.COMPANY]).mean() * 100
            miss = miss.loc[:, miss.sum() > 0]
            if miss.empty:
                st.success("No missing values in any column.")
            else:
                st.plotly_chart(ch.missing_heatmap(miss), width="stretch")

        summary, masks = an.quality_checks(base, date.today())
        with st.container(border=True):
            ui.ptitle("Rule-based checks · invalid dates, non-positive prices, OHLC consistency, suspicious values")
            st.dataframe(summary, width="stretch", hide_index=True, column_config={
                "Rows Flagged": st.column_config.NumberColumn(format="%d")})
            st.caption("**Anomaly** = impossible/inconsistent values. **Review** = unusual but frequently genuine "
                       "market observations; these are flagged, never removed automatically.")
            flagged = summary[summary["Rows Flagged"] > 0]["Check"].tolist()
            if flagged:
                pick = st.selectbox("Inspect flagged rows", flagged, key="f_eda_check")
                ui.stretch_df(base[masks[pick]].head(200),
                              column_config={C.DATE: st.column_config.DateColumn(format="YYYY-MM-DD")})
            else:
                st.success("No rows were flagged by any check.")

        with st.container(border=True):
            ui.ptitle("IQR outlier analysis (1.5 × IQR, computed per company)")
            cols = st.multiselect("Columns", NUM_FOR_EDA, default=[C.CLOSE, C.SHARES, C.TURNOVER, C.RET],
                                  key="f_eda_iqr_cols")
            if cols:
                out = an.iqr_outliers(base, cols)
                st.dataframe(out, width="stretch", hide_index=True, column_config={
                    "Outliers (%)": st.column_config.NumberColumn(format="%.2f")})
                a, b = st.columns([1, 2])
                col = a.selectbox("Box plot of", cols, key="f_eda_box_col")
                b.caption("Outliers in volume, turnover and returns usually mark real market events (earnings, "
                          "index changes, corporate actions). They are shown, not deleted.")
                st.plotly_chart(ch.box_chart(base, col), width="stretch")
                comp = st.selectbox("List outlier rows for", sorted(base[C.COMPANY].unique()), key="f_eda_out_comp")
                ui.stretch_df(an.outlier_rows(base, comp, col).sort_values(col, ascending=False).head(100),
                              column_config={C.DATE: st.column_config.DateColumn(format="YYYY-MM-DD")})

        with st.container(border=True):
            ui.ptitle("Column-wise data quality summary")
            ui.stretch_df(an.column_quality_summary(base))

    # =============================================================== statistics
    with t3:
        with st.container(border=True):
            ui.ptitle("Mean, median, std-dev, min, max per company")
            cols = st.multiselect("Columns", NUM_FOR_EDA, default=[C.CLOSE, C.TURNOVER], key="f_eda_stat_cols")
            if cols:
                ui.stretch_df(an.stats_table(base, cols))
        a, b = st.columns(2)
        with a, st.container(border=True):
            ui.ptitle("Distribution of daily returns")
            st.plotly_chart(ch.histogram(base.dropna(subset=[C.RET]), C.RET, xlabel="Daily return (%)", height=300),
                            width="stretch")
            r = base.groupby(C.COMPANY)[C.RET].agg(["skew", pd.Series.kurt]).round(3)
            r.columns = ["Skewness", "Excess kurtosis"]
            ui.stretch_df(r.reset_index())
        with b, st.container(border=True):
            ui.ptitle("Company-wise volatility (std-dev of daily returns, %)")
            vol = base.groupby(C.COMPANY)[C.RET].std().reset_index(name="Volatility (%)")
            st.plotly_chart(ch.bar(vol.sort_values("Volatility (%)", ascending=False), C.COMPANY, "Volatility (%)", 300),
                            width="stretch")
            st.caption("Includes any one-off corporate-action jumps. See Data quality → 'Daily return > 15%'.")
        a, b = st.columns(2)
        with a, st.container(border=True):
            ui.ptitle("Close price distribution")
            st.plotly_chart(ch.histogram(base, C.CLOSE, xlabel="Close price (Rs.)", height=300), width="stretch")
        with b, st.container(border=True):
            ui.ptitle("Turnover distribution")
            log_t = st.checkbox("Log frequency axis", False, key="f_eda_logy")
            st.plotly_chart(ch.histogram(base.assign(T=base[C.TURNOVER] / 1e7), "T", xlabel="Turnover (Rs. crore)",
                                         height=300, log_y=log_t), width="stretch")
        with st.container(border=True):
            ui.ptitle("Correlation matrix of numeric variables")
            scope = st.selectbox("Scope", ["All companies pooled"] + sorted(base[C.COMPANY].unique()), key="f_eda_corr")
            cdf = base if scope.startswith("All") else base[base[C.COMPANY] == scope]
            cols = st.multiselect("Variables", NUM_FOR_EDA, default=NUM_FOR_EDA, key="f_eda_corr_cols")
            if len(cols) >= 2:
                st.plotly_chart(ch.heatmap(cdf[cols].corr(), 520), width="stretch")
                if scope.startswith("All"):
                    st.caption("Pooled correlations mix companies with very different price levels; price-level "
                               "variables look more correlated or less than they are within one company.")
        with st.container(border=True):
            ui.ptitle("Trading activity and delivery metrics")
            ui.stretch_df(an.activity_table(base), column_config={
                "Avg Shares / Day": st.column_config.NumberColumn(format="%,.0f"),
                "Avg Trades / Day": st.column_config.NumberColumn(format="%,.0f"),
                "Avg Turnover / Day (Rs.)": st.column_config.NumberColumn(format="%,.0f"),
                "Avg Delivery (%)": st.column_config.NumberColumn(format="%.2f"),
                "Avg Deliverable Qty": st.column_config.NumberColumn(format="%,.0f")})
