"""Page modules; each exposes render(df)."""
