"""Smoke-test every page of the Streamlit app headlessly.
Run:  python -m pytest tests -q
"""
from pathlib import Path

import pytest
from streamlit.testing.v1 import AppTest

APP = str(Path(__file__).resolve().parent.parent / "app.py")
PAGES = ["Market Overview", "Stock Explorer", "Exploratory Data Analysis", "Company Comparison",
         "SQL Playground", "Insights & Reports", "Dataset Management"]


def _run(page):
    at = AppTest.from_file(APP, default_timeout=120).run()
    if page != PAGES[0]:
        at.sidebar.radio(key="nav").set_value(page).run()
    return at


@pytest.mark.parametrize("page", PAGES)
def test_page_renders_without_errors(page):
    at = _run(page)
    assert not at.exception, [e.value for e in at.exception]
    assert not at.error, [e.value for e in at.error]


def test_overview_filters_change_kpis():
    at = _run("Market Overview")
    at.selectbox(key="f_ov_company").select("TCS").run()
    assert not at.exception
    html = " ".join(m.value for m in at.markdown)
    assert "Latest close · TCS" in html


def test_sql_question_loads_and_runs():
    at = _run("SQL Playground")
    first = at.text_area(key="sql_editor").value
    assert "FROM stock_data" in first
    at.selectbox(key="sql_q").select("Q06 · Beginner · Average closing price by company").run()
    assert "AVG(close_price)" in at.text_area(key="sql_editor").value
    at.button(key="sql_run").click().run()
    assert not at.exception
    assert len(at.dataframe) >= 2                        # schema + result
    # edit then reset
    at.text_area(key="sql_editor").set_value("SELECT 1").run()
    at.button(key="sql_reset").click().run()
    assert "AVG(close_price)" in at.text_area(key="sql_editor").value


def test_sql_destructive_shows_error():
    at = _run("SQL Playground")
    at.text_area(key="sql_editor").set_value("DROP TABLE stock_data").run()
    at.button(key="sql_run").click().run()
    assert any("read-only" in e.value or "allowed" in e.value for e in at.error)


def test_sql_parameter_question():
    at = _run("SQL Playground")
    at.selectbox(key="sql_q").select("Q09 · Intermediate · Top 5 turnover dates (selected company)").run()
    at.selectbox(key="sql_company").select("Infosys").run()
    assert "company = 'Infosys'" in at.text_area(key="sql_editor").value
