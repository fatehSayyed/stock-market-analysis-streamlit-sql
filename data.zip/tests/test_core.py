"""Core tests: data pipeline, financial calculations, SQL safety and all 28 SQL questions.
Run:  python -m pytest tests -q
"""
import sys
from pathlib import Path

import numpy as np
import pandas as pd
import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from utils import analytics as an          # noqa: E402
from utils import config as C              # noqa: E402
from utils import data_loader as dl        # noqa: E402
from utils import report                   # noqa: E402
from utils import sql_engine as SE         # noqa: E402
from utils import sql_questions as Q       # noqa: E402


@pytest.fixture(scope="module")
def df():
    raw, _ = dl.load_default()
    return an.add_indicators(dl.clean_data(raw).df)


def test_cleaning_shape_and_order(df):
    assert df[C.COMPANY].nunique() == 6
    assert df.duplicated(subset=[C.COMPANY, C.DATE]).sum() == 0
    for _, g in df.groupby(C.COMPANY):
        assert g[C.DATE].is_monotonic_increasing


def test_missing_values_not_imputed(df):
    assert df[C.DELIV].isna().sum() == 6          # as in the source data, left missing


def test_daily_return_matches_manual(df):
    g = df[df[C.COMPANY] == "TCS"].reset_index(drop=True)
    manual = (g[C.CLOSE].iloc[10] / g[C.CLOSE].iloc[9] - 1) * 100
    assert g[C.RET].iloc[10] == pytest.approx(manual)
    assert np.isnan(g[C.RET].iloc[0])             # first day has no return


def test_moving_average_requires_full_window(df):
    g = df[df[C.COMPANY] == "TCS"].reset_index(drop=True)
    assert g[C.MA30].iloc[:29].isna().all() and not np.isnan(g[C.MA30].iloc[29])
    assert g[C.MA30].iloc[29] == pytest.approx(g[C.CLOSE].iloc[:30].mean())
    assert g[C.MA90].iloc[:89].isna().all()


def test_pandas_matches_sql(df):
    assert an.verify_period_returns(df)["Abs Difference"].max() < 1e-9


def test_max_drawdown_is_non_positive(df):
    t = an.max_drawdown_table(df)
    assert (t["Max Drawdown (%)"] <= 0).all()
    assert (t["Peak Date"] <= t["Trough Date"]).all()


@pytest.mark.parametrize("q", Q.QUESTIONS, ids=lambda q: f"Q{q['id']}")
def test_every_question_executes(df, q):
    res = SE.run_query(df, Q.render_sql(q, "TCS", "2015-01-01", "2018-07-31"))
    assert res.error is None, res.error
    assert res.df is not None


def test_question_count_and_levels():
    assert [q["id"] for q in Q.QUESTIONS] == list(range(1, 29))
    assert sum(q["level"] == "Beginner" for q in Q.QUESTIONS) == 8
    assert sum(q["level"] == "Intermediate" for q in Q.QUESTIONS) == 10
    assert sum(q["level"] == "Advanced" for q in Q.QUESTIONS) == 10


@pytest.mark.parametrize("bad", [
    "DROP TABLE stock_data", "DELETE FROM stock_data", "UPDATE stock_data SET close_price = 0",
    "INSERT INTO stock_data VALUES (1)", "ALTER TABLE stock_data ADD COLUMN x INT",
    "SELECT 1; DROP TABLE stock_data", "SELECT * FROM read_csv('/etc/passwd')",
    "COPY stock_data TO 'x.csv'", "ATTACH 'x.db'", "PRAGMA database_list",
    "/* hi */ DELETE FROM stock_data", "CREATE TABLE t AS SELECT 1",
])
def test_destructive_queries_rejected(df, bad):
    assert SE.run_query(df, bad).error is not None


def test_literals_and_comments_do_not_trigger_block(df):
    res = SE.run_query(df, "SELECT COUNT(*) AS n FROM stock_data WHERE company = 'DROP' -- delete me")
    assert res.error is None and res.df.iloc[0, 0] == 0


def test_table_not_modified_between_runs(df):
    SE.run_query(df, "DROP TABLE stock_data")
    assert SE.run_query(df, "SELECT COUNT(*) FROM stock_data").df.iloc[0, 0] == len(df)


def test_row_cap_and_empty_result(df):
    assert SE.run_query(df, "SELECT * FROM stock_data", max_rows=50).truncated
    assert SE.run_query(df, "SELECT * FROM stock_data WHERE 1=0").df.empty


def test_sql_error_message_is_clear(df):
    res = SE.run_query(df, "SELECT nope FROM stock_data")
    assert res.error and "nope" in res.error.lower()


def test_pdf_builds(df):
    d = an.filter_df(df, None, "2016-01-01", "2017-12-31")
    summary, _ = an.quality_checks(df.drop(columns=[C.MA30, C.MA90]))
    pdf = report.build_pdf(df, d, "2016-01-01", "2017-12-31", {"TCS": "Example observation"}, summary, "test")
    assert pdf[:4] == b"%PDF" and len(pdf) > 20_000
